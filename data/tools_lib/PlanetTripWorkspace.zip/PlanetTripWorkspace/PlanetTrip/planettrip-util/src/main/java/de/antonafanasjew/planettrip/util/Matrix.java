package de.antonafanasjew.planettrip.util;



public class Matrix<T> {

	public int w;
	public int h;
	
	private T[][] rows = null;
	
	@SuppressWarnings("unchecked")
	public Matrix(int w, int h) {
		this.w = w;
		this.h = h;
		
		rows = (T[][])new Object[h][w];
		
	}
	
	public Matrix(T[][] data) {
		rows = data;
		w = data[0].length;
		h = data.length;
	}
	
	public void setElement(T element, int x, int y) {
		rows[x][y] = element;
	}
	
	public T getElement(int x, int y) {
		return rows[x][y];
	}
	
	public Matrix<T> excerpt(int xPos, int yPos, int width, int height) {
		Matrix<T> excerpt = new Matrix<T>(width, height);
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				excerpt.setElement(getElement(xPos + x, yPos + y), x, y);
			}
		}
		return excerpt;
	}
	
}
