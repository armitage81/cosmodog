package de.antonafanasjew.planettrip.tiled.processing;


public interface VerticalBuilderRuleProvider {

	VerticalBuilderRules provideVerticalBuilderRules();
	
}
