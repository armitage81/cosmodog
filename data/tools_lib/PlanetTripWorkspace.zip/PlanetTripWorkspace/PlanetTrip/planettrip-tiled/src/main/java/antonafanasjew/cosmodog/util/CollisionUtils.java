package antonafanasjew.cosmodog.util;

import java.util.List;

import com.google.common.collect.Lists;

import antonafanasjew.cosmodog.topology.PlacedRectangle;
import antonafanasjew.cosmodog.topology.Position;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledEllipseObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledFigureObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledLineObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledLineObject.Point;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledPolygonObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledPolylineObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledRectObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTileObject;

public class CollisionUtils {

	public static boolean intersects(PlacedRectangle r, TiledObject region) {
		if (region instanceof TiledFigureObject) {
			return intersects(r, (TiledFigureObject) region);
		} else if (region instanceof TiledLineObject) {
			return intersects(r, (TiledLineObject) region);
		} else if (region instanceof TiledTileObject) {
			return intersects(r, (TiledTileObject) region);
		} else {
			return false;
		}
	}

	private static boolean intersects(PlacedRectangle r, TiledFigureObject region) {
		if (region instanceof TiledRectObject) {
			return intersects(r, (TiledRectObject) region);
		} else if (region instanceof TiledEllipseObject) {
			return intersects(r, (TiledEllipseObject) region);
		} else {
			return false;
		}
	}

	private static boolean intersects(PlacedRectangle r, TiledLineObject region) {
		if (region instanceof TiledPolylineObject) {
			return intersects(r, (TiledPolylineObject) region);
		} else if (region instanceof TiledPolygonObject) {
			return intersects(r, (TiledPolygonObject) region);
		} else {
			return false;
		}
	}

	private static boolean intersects(PlacedRectangle r, TiledRectObject region) {
		PlacedRectangle regionRectangle = PlacedRectangle.fromAnchorAndSize(region.getX(), region.getY(), region.getWidth(), region.getHeight());
		return r.intersection(regionRectangle) != null;
	}

	private static boolean intersects(PlacedRectangle r, TiledEllipseObject region) {
		throw new RuntimeException("Not implemented");
	}

	private static boolean intersects(PlacedRectangle r, TiledPolylineObject region) {
		throw new RuntimeException("Not implemented");
	}
	
	/**
	 * Returns true if the placed rectangle intersects (actually contains) a position.
	 * @param r Rectangle
	 * @param position Point
	 * @return true if the position is within the rectangle, false otherwise.
	 */
	public static boolean intersects(PlacedRectangle r, Position position) {
		float x1 = r.minX();
		float x2 = r.maxX();
		float y1 = r.minY();
		float y2 = r.maxY();
		
		float x = position.getX();
		float y = position.getY();
		
		return x >= x1 && x < x2 && y >= y1 && y < y2;
		
	}

	/*
	 * Take care. The intersection relates on the center of the region. If the polygon intrudes the region slightly without crossing its center, it is considered to be non intersecting. 
	 */
	private static boolean intersects(PlacedRectangle r, TiledPolygonObject region) {

		Point p = new Point(r.centerX(), r.centerY());
		
		List<Point> points = region.getPoints();
				
		List<Point> pointsCopy = Lists.newArrayList();
		//This we don't do in the cosmodog project as there we are working with the custom tiled map where this calculation is done during
		//the initialization. In the tiled map project, this does not happen, so we have to add the adjustment here.
		
		for (Point point : points) {
			Point pointCopy = new Point(region.getX() + point.x, region.getY() + point.y);
			pointsCopy.add(pointCopy);
		}
		

		//As described at: http://stackoverflow.com/questions/8721406/how-to-determine-if-a-point-is-inside-a-2d-convex-polygon
		int i;
		int j;
		boolean result = false;
		for (i = 0, j = pointsCopy.size() - 1; i < pointsCopy.size(); j = i++) {
			if ((pointsCopy.get(i).y > p.y) != (pointsCopy.get(j).y > p.y) && (p.x < (pointsCopy.get(j).x - pointsCopy.get(i).x) * (p.y - pointsCopy.get(i).y) / (pointsCopy.get(j).y - pointsCopy.get(i).y) + pointsCopy.get(i).x)) {
				result = !result;
			}
		}
		
		return result;
		

	}

	private static boolean intersects(PlacedRectangle r, TiledTileObject region) {
		throw new RuntimeException("Not implemented");
	}

}
