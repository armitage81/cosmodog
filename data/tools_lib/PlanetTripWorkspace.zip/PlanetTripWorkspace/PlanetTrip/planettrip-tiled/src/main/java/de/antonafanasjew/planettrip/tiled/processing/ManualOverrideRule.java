package de.antonafanasjew.planettrip.tiled.processing;

//This rule give a layer (overrideLayerName) in which all of tiles with the id (originalTileId)
//will be replaced by tiles with the id (replacementTileId) if they are in regions that are
//defined in the region layer(regionLayerName). Regions are defined by tiles with the given tile id (regionTileId).
//This way, different regions can be defined on the same region layer as long as they are disjoint.
public class ManualOverrideRule {
	//The tiles in which layer should be overridden
	public String overrideLayerName;
	//What is the layer name that holds the overriding regions information
	public String regionLayerName;
	//Which tile id marks the region
	public int regionTileId;
	//Which tile should be overridden
	public int originalTileId;
	//Which tile should be the replacement
	public int replacementTileId;
	
	@Override
	public String toString() {
		return overrideLayerName + ", " + regionLayerName + ", " + regionTileId + ", " + originalTileId + ", " + replacementTileId;
	}
	
}
