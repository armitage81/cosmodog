package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.jdom2.JDOMException;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.util.Matrix;

public class ManualOverrideTiledMapProcessor extends AbstractTiledMapProcessor {

	private ManualOverrideRules rules = new ManualOverrideRules();
	
	public ManualOverrideTiledMapProcessor(ManualOverrideRuleProvider ruleProvider) throws JDOMException, IOException {
		rules = ruleProvider.provideManualOverrideRules();
	}
	
	@Override
	public void process(TiledMap tiledMap) {
		System.out.println("Starting manual overriding");
		
		Map<String, TiledMapLayer> layerByNameCache = Maps.newHashMap();
		Map<Integer, TiledMapLayer> layerByNumberCache = Maps.newHashMap();
		Map<String, Integer> layerNumberByNameCache = Maps.newHashMap();
		
		List<Matrix<TiledTile>> allLayersTiles = Lists.newArrayList();
		
		int layerNumber = 0;
		for (TiledMapLayer l : tiledMap.getMapLayers()) {
			layerByNameCache.put(l.getName(), l);
			layerByNumberCache.put(layerNumber, l);
			layerNumberByNameCache.put(l.getName(), layerNumber);
			allLayersTiles.add(l.getDataAsMatrix());
			layerNumber++;
		}


		// Go through each layer rule
		for (ManualOverrideRule rule : rules) {


			// Get region layer data for the rule to know where replacements
			// should be done.
			TiledMapLayer regionLayer = layerByNameCache.get(rule.regionLayerName);
			TiledMapLayer overrideLayer = layerByNameCache.get(rule.overrideLayerName);
			
			Matrix<TiledTile> regionLayerTiles = regionLayer.getDataAsMatrix();
			Matrix<TiledTile> overrideTiles = overrideLayer.getDataAsMatrix();

			int regionLayerNumber = layerNumberByNameCache.get(rule.regionLayerName);
			int overrideLayerNumber = layerNumberByNameCache.get(rule.overrideLayerName);

			// Go through all layer tiles and replace all tiles with the id as
			// in rule if they are in the region
			for (int k = 0; k < overrideTiles.w; k++) {
				for (int l = 0; l < overrideTiles.h; l++) {

					// Ignore the tile if there are other tiles between the
					// override layer and the region layer.
					boolean breakIt = false;

					//Check if there are tiles between the region and override layers. Don't override such tiles.
					for (int m = regionLayerNumber + 1; m < overrideLayerNumber; m++) {
						TiledTile betweenLayerTile = allLayersTiles.get(m).getElement(k, l);
						if (betweenLayerTile.getGid() != 0) {
							breakIt = true;
							break;
						}
					}

					if (breakIt) {
						continue;
					}

					TiledTile tile = overrideTiles.getElement(k, l);
					TiledTile regionLayerTile = regionLayerTiles.getElement(k, l);

					if (regionLayerTile.getGidAsTileNumber() == rule.regionTileId) {
						if (tile.getGidAsTileNumber() == rule.originalTileId) {
							tile.setGidFromTileNumber(rule.replacementTileId);
						}
					}
				}
			}
				
		}
		
		System.out.println("Manual override complete");		
	}

}
