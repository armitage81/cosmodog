package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;

import org.jdom2.Element;

import de.antonafanasjew.planettrip.tiled.processingresources.TilesetDescriptor;
import de.antonafanasjew.planettrip.tiled.processingresources.TilesetDescriptors;

public class TilesetDescriptorProvider extends AbstractResourceProvider<TilesetDescriptors> {

	@Override
	protected TilesetDescriptors resourceFromRootElement(Element root) {
		TilesetDescriptors retVal = new TilesetDescriptors();
		
		List<Element> tilesetElements = root.getChildren("tileset");
		
		for (Element tilesetElement : tilesetElements) {
			TilesetDescriptor tilesetResource = new TilesetDescriptor();
			tilesetResource.group = tilesetElement.getAttributeValue("group");
			tilesetResource.hint = tilesetElement.getAttributeValue("hint");
			tilesetResource.tileNumbers = tilesetElement.getAttributeValue("tileNumbers");
			tilesetResource.type = tilesetElement.getAttributeValue("type");
			retVal.add(tilesetResource);
		}
		
		return retVal;
	}

}
