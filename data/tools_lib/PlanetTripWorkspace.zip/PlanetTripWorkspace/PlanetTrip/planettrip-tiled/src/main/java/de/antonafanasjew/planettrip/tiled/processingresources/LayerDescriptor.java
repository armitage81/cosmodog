package de.antonafanasjew.planettrip.tiled.processingresources;

public class LayerDescriptor {
	public String name;
	public boolean top; //Covers the character (Like a tower)
	public boolean tip; //Covers the character partially (Like a grass field)
	public boolean alt; //Describes alternative layer that is used for animations (e.g. water)
	public boolean meta;
}
