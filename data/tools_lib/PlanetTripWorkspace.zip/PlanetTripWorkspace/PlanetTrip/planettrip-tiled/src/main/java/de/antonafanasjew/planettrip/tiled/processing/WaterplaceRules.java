package de.antonafanasjew.planettrip.tiled.processing;

import java.util.ArrayList;

public class WaterplaceRules extends ArrayList<WaterplaceRule> {

	private static final long serialVersionUID = 4578095100521992349L;

}
