package de.antonafanasjew.planettrip.tiled.tiledmap;

import java.util.List;

import com.google.common.collect.Lists;

public abstract class TiledLineObject extends TiledObject {

	public static class Point {
		public float x;
		public float y;
		
		@Override
		public String toString() {
			return String.valueOf(x) + "," + String.valueOf(y);
		}
		
		public Point(float x, float y) {
			this.x = x;
			this.y = y;
		}

		public Point() {

		}
	}
	
	private List<Point> points = Lists.newArrayList();

	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}
	
}
