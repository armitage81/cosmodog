package de.antonafanasjew.planettrip.tiled.processingresources;

import java.util.HashSet;
import java.util.Set;

import com.google.common.collect.Sets;

public class TilesetDescriptors extends HashSet<TilesetDescriptor> {

	private static final long serialVersionUID = 7665552558965612941L;
	
	public Set<TilesetDescriptor> getTilesetResourcesForGroup(String group) {
	
		Set<TilesetDescriptor> retVal = Sets.newHashSet();
		
		for (TilesetDescriptor res : this) {
			if (res.group.equals(group)) {
				retVal.add(res);
			}
		}
		
		return retVal;
		
	}

}
