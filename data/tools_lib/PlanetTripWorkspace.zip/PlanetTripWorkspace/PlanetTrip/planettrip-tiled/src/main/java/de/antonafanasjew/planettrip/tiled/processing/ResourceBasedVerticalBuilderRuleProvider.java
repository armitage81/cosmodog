package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;

public class ResourceBasedVerticalBuilderRuleProvider implements VerticalBuilderRuleProvider {

	VerticalBuilderRules rules = new VerticalBuilderRules();
	
	public ResourceBasedVerticalBuilderRuleProvider() throws IOException {
		InputStream resourceStream = ResourceBasedVerticalBuilderRuleProvider.class.getClassLoader().getResourceAsStream("de/antonafanasjew/planettrip/tiled/verticalbuilder.rules");
		String resouceContent = CharStreams.toString(new InputStreamReader(resourceStream, Charsets.UTF_8));
		String[] lines = resouceContent.split(System.getProperty("line.separator"));
		
		for (String line : lines) {
			VerticalBuilderRule rule = new VerticalBuilderRule();
			
			String[] parts = line.split(":");
			
			rule.layer1 = parts[0];
			rule.layer2 = parts[1];
			
			String partWithMappings = parts[2];
			
			String[] mappings = partWithMappings.split(",");
			
			for (String mapping : mappings) {
				String[] bothTiles = mapping.split("=");
				rule.layer1TileNumbers.add(Integer.parseInt(bothTiles[0]));
				rule.layer2TileNumbers.add(Integer.parseInt(bothTiles[1]));
			}
			
			
			rules.add(rule);
		}
	}
	
	
	@Override
	public VerticalBuilderRules provideVerticalBuilderRules() {
		return rules;
	}

}
