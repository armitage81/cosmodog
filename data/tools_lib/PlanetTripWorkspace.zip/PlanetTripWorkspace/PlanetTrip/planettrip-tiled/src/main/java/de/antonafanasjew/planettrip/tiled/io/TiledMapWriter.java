package de.antonafanasjew.planettrip.tiled.io;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;

public interface TiledMapWriter {

	void writeTiledMap(TiledMap tiledMap) throws TiledMapIoException;
	
}
