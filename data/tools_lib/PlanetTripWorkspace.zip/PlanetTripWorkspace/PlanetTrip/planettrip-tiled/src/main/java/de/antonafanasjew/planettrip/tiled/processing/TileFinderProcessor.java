package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;

import com.google.common.collect.Lists;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.util.Matrix;

/**
 * Returning the same map without processing it. Can be useful to shorten up the
 * test when only reading and writing of the map are interesting.
 */
public class TileFinderProcessor extends AbstractTiledMapProcessor {

	private String layerName = null;
	private List<Integer> tileIds = Lists.newArrayList();

	public TileFinderProcessor(int... tileIds) {
		this(null, tileIds);
	}

	public TileFinderProcessor(String layerName, int... tileIds) {
		this.layerName = layerName;
		for (int tileId : tileIds) {
			this.tileIds.add(tileId);
		}
	}

	@Override
	public void process(TiledMap tiledMap) {
		int c = 0;
		for (int n = 0; n < tiledMap.getMapLayers().size(); n++) {
			TiledMapLayer layer = tiledMap.getMapLayers().get(n);

			if (layerName == null || layerName.equals(layer.getName())) {

				Matrix<TiledTile> tiles = layer.getDataAsMatrix();

				for (int i = 0; i < tiles.w; i++) {
					for (int j = 0; j < tiles.h; j++) {
						int tileId = tiles.getElement(i, j).getGidAsTileNumber();
						if (tileIds.contains(tileId)) {
							c++;
							System.out.println("Layer: " + layer.getName() + ": " + i + "/" + j + (" (" + tileId + ")"));
						}
					}
				}

			}
		}
		System.out.println("Count: " + c);
		System.out.println("Count / 400: " + c / 400);
	}

}
