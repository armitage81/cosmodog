package de.antonafanasjew.planettrip.tiled.tiledmap;

public class TiledPolylineObject extends TiledLineObject {

}
