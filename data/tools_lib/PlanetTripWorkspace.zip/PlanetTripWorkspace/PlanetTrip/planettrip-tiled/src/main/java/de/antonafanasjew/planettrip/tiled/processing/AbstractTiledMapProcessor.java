package de.antonafanasjew.planettrip.tiled.processing;

public abstract class AbstractTiledMapProcessor implements TiledMapProcessor {

	
	
}
