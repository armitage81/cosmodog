package de.antonafanasjew.planettrip.tiled.processing;

import java.util.ArrayList;

public class ObjectDistributionRules extends ArrayList<ObjectDistributionRule> {

	private static final long serialVersionUID = -5017869643786723618L;

}
