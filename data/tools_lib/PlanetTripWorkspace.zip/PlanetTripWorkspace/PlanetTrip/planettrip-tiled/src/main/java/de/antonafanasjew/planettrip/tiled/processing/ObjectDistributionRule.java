package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;

import com.google.common.collect.Lists;

public class ObjectDistributionRule {
	public String layer;
	public String undergroundLayer;
	public List<Integer> undergroundTileNumbers = Lists.newArrayList();
	public int tileNumber;
	public float weight;
}
