package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;
import java.util.List;

import org.jdom2.JDOMException;

import com.google.common.collect.Lists;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.util.Matrix;

public class CleanupTiledMapProcessor extends AbstractTiledMapProcessor {

	private List<Integer> tileIds = Lists.newArrayList();
	
	public CleanupTiledMapProcessor(List<Integer> tileIds) throws JDOMException, IOException {
		this.tileIds = tileIds;
	}
	
	@Override
	public void process(TiledMap tiledMap) {
		System.out.println("Starting cleanup");
		
		for (int n = 0; n < tiledMap.getMapLayers().size(); n++) {
			TiledMapLayer layer = tiledMap.getMapLayers().get(n);

			Matrix<TiledTile> tiles = layer.getDataAsMatrix();

			for (int i = 0; i < tiles.w; i++) {
				for (int j = 0; j < tiles.h; j++) {
					if (tileIds.contains(tiles.getElement(i, j).getGidAsTileNumber())) {
						System.out.println("Layer: " + layer.getName() + ": " + i + "/" + j);
						TiledTile layerTile = tiles.getElement(i, j);
						layerTile.setGid(0);
					}
				}
			}

		}
		
		System.out.println("Cleanup complete");		
	}

}
