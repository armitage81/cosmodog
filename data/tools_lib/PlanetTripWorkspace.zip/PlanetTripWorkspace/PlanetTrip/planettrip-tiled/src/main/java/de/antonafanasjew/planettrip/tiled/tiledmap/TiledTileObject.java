package de.antonafanasjew.planettrip.tiled.tiledmap;

public class TiledTileObject extends TiledObject {

	private int gid;

	public int getGid() {
		return gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}
	
}
