package de.antonafanasjew.planettrip.tiled.arithmetics;

public interface MarkableMatrixElement {

	boolean isMarked();
	Object getMark();
	
}
