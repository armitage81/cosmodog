package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;

import de.antonafanasjew.planettrip.tiled.arithmetics.MatrixNeighbourhood;
import de.antonafanasjew.planettrip.tiled.arithmetics.NeighbourhoodProvider;
import de.antonafanasjew.planettrip.tiled.arithmetics.UnknownNeighbourhoodException;
import de.antonafanasjew.planettrip.tiled.tiledmap.TileMarker;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.util.Matrix;

public class EdgeLayoutTiledMapProcessor extends AbstractTiledMapProcessor {

	private LayoutRules rules = new LayoutRules();

	public EdgeLayoutTiledMapProcessor(ResourceProvider<LayoutRules> resourceProvider) throws IOException {
		rules = resourceProvider.provideResource(null);
	}

	@Override
	public void process(TiledMap tiledMap) {
		
		System.out.println("Starting edge layout");
		
		for (TiledMapLayer layer : tiledMap.getMapLayers()) {
			
			//Ignore tops
			
			if (layer.getName().contains("_top")) {
				System.out.println("Ignoring the layer " + layer.getName() + " as it is \"top\"");
				continue;
			}
			
			System.out.println("Laying out layer " + layer.getName());
			
			Matrix<TiledTile> layerTiles = layer.getDataAsMatrix();

			int count = 0;
			int ignoredCount = 0;

			for (LayoutRule rule : rules) {

				for (int k = 0; k < layerTiles.w; k++) {
					for (int l = 0; l < layerTiles.h; l++) {
						TiledTile tile = layerTiles.getElement(k, l);
						TileMarker marker = new TileMarker(tile, rule);
						tile.setDelegate(marker);
					}
				}

				
				for (int k = 0; k < layerTiles.w; k++) {
					for (int l = 0; l < layerTiles.h; l++) {

						TiledTile tile = layerTiles.getElement(k, l);

						if (tile.isMarked() == false) {
							NeighbourhoodProvider<TiledTile> neighbourhoodProvider = new NeighbourhoodProvider<TiledTile>(layerTiles);
							try {
								MatrixNeighbourhood neighbourhood = neighbourhoodProvider.provideNeighbourhood(k, l);
								if (neighbourhood != MatrixNeighbourhood.none) {
									Integer edgeTileNumber = rule.edgeTileNumbers.get(neighbourhood).selectAtRandom();
									if (rule.tileNumbersNoOverride.contains(tile.getGidAsTileNumber()) == false) {
										tile.setGidFromTileNumber(edgeTileNumber);
										count++;
									} else {
										System.out.println("Ignoring the tile at layer " + layer.getName() + " (" + k + ", " + l + ")");
										ignoredCount++;
									}
								}
							} catch (UnknownNeighbourhoodException e) {
								tile.setGidFromTileNumber(27);
								System.err.println(e.getLocalizedMessage() + " at layer " + layer.getName() + " (" + k + ", " + l + ")");
							}

						}
					}
				}
				
			}
			System.out.println("Layed out " + count + " tiles for layer " + layer.getName() + " (" + ignoredCount + " ignored)");
		}
		
		System.out.println("Edge layout complete");
	}

}
