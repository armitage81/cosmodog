package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

import de.antonafanasjew.planettrip.tiled.arithmetics.MatrixNeighbourhood;

public class ResourceBasedLayoutRuleProvider implements ResourceProvider<LayoutRules> {

	LayoutRules rules = new LayoutRules();
	
	public ResourceBasedLayoutRuleProvider() throws IOException, JDOMException {
		
		InputStream resourceStream = EdgeLayoutTiledMapProcessor.class.getClassLoader().getResourceAsStream("de/antonafanasjew/planettrip/tiled/tilelayout.rules");
        SAXBuilder jdomBuilder = new SAXBuilder();
        Document jdomDocument = jdomBuilder.build(resourceStream);
  
        Element root = jdomDocument.getRootElement();
		
        List<Element> tileTypeElements = root.getChildren("tileType");
        
        for (Element tileTypeElement : tileTypeElements) {
        
			LayoutRule rule = new LayoutRule();
			rule.tileName = tileTypeElement.getAttributeValue("name");
			String mainTileNumbers = tileTypeElement.getChildText("mainTiles");

			
			TileSelector tileSelector = selectorFromString(mainTileNumbers);
			rule.tileSelector = tileSelector;

			String edgeTileNumbers = tileTypeElement.getChildText("edgeTiles");

			String[] edgeTileNumberRepresentations = edgeTileNumbers.split(",");
			
			TileSelector[] edgeTileSelectors = new TileSelector[edgeTileNumberRepresentations.length];
			
			for (int i = 0; i < edgeTileNumberRepresentations.length; i++) {
				edgeTileSelectors[i] = selectorFromString(edgeTileNumberRepresentations[i]);
			}
			

			rule.edgeTileNumbers.put(MatrixNeighbourhood.east, edgeTileSelectors[0]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.southEast, edgeTileSelectors[1]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.south, edgeTileSelectors[2]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.southWest, edgeTileSelectors[3]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.west, edgeTileSelectors[4]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.northWest, edgeTileSelectors[5]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.north, edgeTileSelectors[6]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.northEast, edgeTileSelectors[7]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.northAndWest, edgeTileSelectors[8]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.northAndEast, edgeTileSelectors[9]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.southAndEast, edgeTileSelectors[10]);
			rule.edgeTileNumbers.put(MatrixNeighbourhood.southAndWest, edgeTileSelectors[11]);

			String noOverrideTileNumbers = tileTypeElement.getChildText("lockedTiles");
			
			if (noOverrideTileNumbers != null) {
				String[] noOverrideTileNumbersRepresentations = noOverrideTileNumbers.split(",");
				
				for (String noOverrideTileNumbersRepresentation : noOverrideTileNumbersRepresentations) {
					rule.tileNumbersNoOverride.add(Integer.parseInt(noOverrideTileNumbersRepresentation));
				}
			}
			
			rules.add(rule);
		}
	}
		
	private TileSelector selectorFromString(String string) {
		
		TileSelector retVal = new TileSelector();
		
		String[] candidatesRepresentations;
		
		if (string.contains(";")) {
			candidatesRepresentations = string.split(";");
		} else {
			candidatesRepresentations = new String[]{string};
		}
		
		for (String candidatesRepresentation : candidatesRepresentations) {
			if (candidatesRepresentation.contains("=")) {
				String[] parts = candidatesRepresentation.split("=");
				retVal.candidates.put(Integer.parseInt(parts[0]), Float.parseFloat(parts[1]));
			} else {
				retVal.candidates.put(Integer.parseInt(candidatesRepresentation), 1f);
			}
		}
		
		return retVal;
	}

	@Override
	public LayoutRules provideResource(String path) {
		return rules;
	}

	public static void main(String[] args) throws IOException, JDOMException {
		ResourceBasedLayoutRuleProvider p = new ResourceBasedLayoutRuleProvider();
		LayoutRules rules = p.provideResource(null);
		System.out.println(rules);
	}
	
}
