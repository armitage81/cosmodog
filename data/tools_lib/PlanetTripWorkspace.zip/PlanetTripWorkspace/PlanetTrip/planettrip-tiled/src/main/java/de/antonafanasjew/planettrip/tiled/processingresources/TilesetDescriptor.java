package de.antonafanasjew.planettrip.tiled.processingresources;

public class TilesetDescriptor {
	
	public static final String TYPE_CONVENTION_CONVEX = "CONVENTION_CONVEX";
	public static final String TYPE_CONVENTION_CONCAV_INNER = "CONVENTION_CONCAV_INNER";
	public static final String TYPE_CONVENTION_CONCAV_OUTER = "CONVENTION_CONCAV_OUTER";
	public static final String TYPE_CONVENTION_BORDER_CONVEX = "CONVENTION_BORDER_CONVEX";
	public static final String TYPE_CONVENTION_BORDER_CONCAV_OUTER = "CONVENTION_BORDER_CONCAV_OUTER";
	public static final String TYPE_CONVENTION_BORDER_CONCAV_INNER = "CONVENTION_BORDER_CONCAV_INNER";
	public static final String TYPE_TILESET = "TILESET";
	
	public String group;
	public String type;
	public String tileNumbers;
	public String hint;
}
