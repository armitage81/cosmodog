package de.antonafanasjew.planettrip.tiled.processing;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;

public interface TiledMapProcessor {

	void process(TiledMap tiledMap);
	
}
