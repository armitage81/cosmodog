package de.antonafanasjew.planettrip.tiled.arithmetics;

import de.antonafanasjew.planettrip.util.Matrix;

public class NeighbourhoodProvider<T extends MarkableMatrixElement> {

	Matrix<T> matrix;
	
	public NeighbourhoodProvider(Matrix<T> matrix) {
		this.matrix = matrix;
	}
	
	public short provideNeighbourhoodId(int x, int y) {
		boolean[] neighbours = new boolean[8];
		neighbours[0] = x > 0 && matrix.getElement(x - 1, y).isMarked();
		neighbours[1] = x > 0 && y > 0 && matrix.getElement(x - 1, y - 1).isMarked();
		neighbours[2] = y > 0 && matrix.getElement(x, y - 1).isMarked();
		neighbours[3] = x < matrix.w - 1 && y > 0 && matrix.getElement(x + 1, y - 1).isMarked();
		neighbours[4] = x < matrix.w - 1 && matrix.getElement(x + 1, y).isMarked();
		neighbours[5] = x < matrix.w - 1 && y < matrix.h - 1 && matrix.getElement(x + 1, y + 1).isMarked();
		neighbours[6] = y < matrix.h - 1 && matrix.getElement(x, y + 1).isMarked();
		neighbours[7] = x > 0 && y < matrix.h - 1 && matrix.getElement(x - 1, y + 1).isMarked();
		
		short neighbourhoodId = 0;
		
		for (int i = 0; i < 8; i++) {
			short controlByte = neighbours[i] ? (short)1 : (short)0;
			controlByte = (short)(controlByte << (7 - i));
			neighbourhoodId |= controlByte;
		}
		
		return neighbourhoodId;
	}
	
	public MatrixNeighbourhood provideNeighbourhood(int x, int y) throws UnknownNeighbourhoodException {
		short neighbourhoodId = provideNeighbourhoodId(x, y);
		return MatrixNeighbourhood.getByNeighbourhoodId(neighbourhoodId);
		
	}
	
}
