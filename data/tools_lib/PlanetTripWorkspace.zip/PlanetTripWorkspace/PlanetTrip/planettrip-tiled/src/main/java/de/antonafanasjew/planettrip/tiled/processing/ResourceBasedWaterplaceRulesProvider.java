package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;

import org.jdom2.Element;

public class ResourceBasedWaterplaceRulesProvider extends AbstractResourceProvider<WaterplaceRules> implements ResourceProvider<WaterplaceRules> {

	@Override
	protected WaterplaceRules resourceFromRootElement(Element root) {
		
		WaterplaceRules retVal = new WaterplaceRules();
		
		List<Element> waterplaceElements = root.getChildren("waterplace");
		
		for (Element waterplaceElement : waterplaceElements) {
			retVal.add(waterplaceRuleFromElement(waterplaceElement));
		}
		
		return retVal;
	}

	private WaterplaceRule waterplaceRuleFromElement(Element waterplaceElement) {
		WaterplaceRule retVal = new WaterplaceRule();
		
		retVal.description = waterplaceElement.getAttributeValue("description");
		retVal.type = waterplaceElement.getAttributeValue("type");
		retVal.waterMarkerTileNumber = Integer.parseInt(waterplaceElement.getAttributeValue("waterMarkerTileNumber"));
		retVal.closeToWaterMarkerTileNumber = Integer.parseInt(waterplaceElement.getAttributeValue("closeToWaterMarkerTileNumber"));
		retVal.markerLayer = waterplaceElement.getAttributeValue("markerLayer");
		
		List<Element> tilesetRefElements = waterplaceElement.getChildren("tileset-ref");
		
		for (Element tilesetRefElement : tilesetRefElements) {
			String group = tilesetRefElement.getAttributeValue("group");
			retVal.tilesetReferences.add(group);
		}
		
		Element ignoreElement = waterplaceElement.getChild("ignore");
		if (ignoreElement != null) {
			List<Element> ignoreTilesetRefElements = ignoreElement.getChildren("tileset-ref");
			for (Element ignoreTilesetRefElement : ignoreTilesetRefElements) {
				String group = ignoreTilesetRefElement.getAttributeValue("group");
				retVal.ignoreTilesetReferences.add(group);
			}
		}
		
		return retVal;
	}

}
