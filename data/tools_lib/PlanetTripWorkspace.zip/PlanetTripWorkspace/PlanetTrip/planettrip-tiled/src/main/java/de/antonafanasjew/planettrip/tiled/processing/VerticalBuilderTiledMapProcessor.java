package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.util.Matrix;

public class VerticalBuilderTiledMapProcessor extends AbstractTiledMapProcessor {

	private VerticalBuilderRules rules = new VerticalBuilderRules();
	
	public VerticalBuilderTiledMapProcessor(VerticalBuilderRuleProvider provider) {
		rules = provider.provideVerticalBuilderRules();
	}
	
	@Override
	public void process(TiledMap tiledMap) {
		System.out.println("Starting vertical building.");
		
		Map<String, TiledMapLayer> layerByNameCache = Maps.newHashMap();
		Map<Integer, TiledMapLayer> layerByNumberCache = Maps.newHashMap();
		
		List<Matrix<TiledTile>> allLayersTiles = Lists.newArrayList();
		
		int layerNumber = 0;
		for (TiledMapLayer l : tiledMap.getMapLayers()) {
			layerByNameCache.put(l.getName(), l);
			layerByNumberCache.put(layerNumber, l);
			allLayersTiles.add(l.getDataAsMatrix());
			layerNumber++;
		}
		
		layerNumber = 0;
		
		for (VerticalBuilderRule rule : rules) {
			System.out.println("Processing vertical dependencies between " + rule.layer1 + " <-> " + rule.layer2);
			
			String layer1Name = rule.layer1;
			String layer2Name = rule.layer2;
			
			
			TiledMapLayer layer1 = layerByNameCache.get(layer1Name);
			TiledMapLayer layer2 = layerByNameCache.get(layer2Name);
			
			Matrix<TiledTile> layer1Matrix = layer1.getDataAsMatrix();
			Matrix<TiledTile> layer2Matrix =  layer2.getDataAsMatrix();
			
			for (int k = 0; k < layer1Matrix.w; k++) {
				for (int l = 0; l < layer1Matrix.h; l++) {
					TiledTile tile1 = layer1Matrix.getElement(k, l);
					TiledTile tile2 = layer2Matrix.getElement(k, l);
					
					if (tile1.getGid() == 0 && tile2.getGid() == 0) {
						continue;
					}
					
					if (tile1.getGid() == 0) {
						for (int m = 0; m < rule.layer2TileNumbers.size(); m++) {
							if (tile2.getGidAsTileNumber() == rule.layer2TileNumbers.get(m)) {
								tile1.setGidFromTileNumber(rule.layer1TileNumbers.get(m));
							}
						}
					}
					
					if (tile2.getGid() == 0) {
						for (int m = 0; m < rule.layer1TileNumbers.size(); m++) {
							if (tile1.getGidAsTileNumber() == rule.layer1TileNumbers.get(m)) {
								tile2.setGidFromTileNumber(rule.layer2TileNumbers.get(m));
							}
						}
					}
					
				}
			}
			
			
		}
	}

}
