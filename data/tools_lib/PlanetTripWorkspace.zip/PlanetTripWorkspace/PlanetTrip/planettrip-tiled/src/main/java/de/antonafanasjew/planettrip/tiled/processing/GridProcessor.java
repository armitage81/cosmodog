package de.antonafanasjew.planettrip.tiled.processing;

import java.util.Map;

import com.google.common.collect.Maps;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.util.Matrix;

public class GridProcessor extends AbstractTiledMapProcessor {

	private String layerName;
	private int gridTileSize;
	private int tileNumberA;
	private int tileNumberB;

	public GridProcessor(String layerName, int gridTileSize, int tileNumberA, int tileNumberB) {
		this.layerName = layerName;
		this.gridTileSize = gridTileSize;
		this.tileNumberA = tileNumberA;
		this.tileNumberB = tileNumberB;
	}
	
	@Override
	public void process(TiledMap tiledMap) {
		Map<String, TiledMapLayer> layerByNameCache = Maps.newHashMap();
		
		for (TiledMapLayer l : tiledMap.getMapLayers()) {
			layerByNameCache.put(l.getName(), l);
		}
		
		TiledMapLayer layer = layerByNameCache.get(layerName);
		
		Matrix<TiledTile> layerData = layer.getDataAsMatrix();
		
		for (int i = 0; i < layerData.w; i++) {
			System.out.println("Line: " + i);
			for (int j = 0; j < layerData.h; j++) {
				int gridTileNoX = i / gridTileSize;
				int gridTileNoY = j / gridTileSize;
				
				boolean even = ((gridTileNoX + gridTileNoY) % 2) == 0;
				layerData.getElement(i, j).setGid(even ? tileNumberA :tileNumberB);
			}
		}
		
		System.out.println("Finished");
		
	}

}
