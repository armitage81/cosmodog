package de.antonafanasjew.planettrip.tiled.start;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.GregorianCalendar;
import java.util.Map;

import org.jdom2.JDOMException;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.io.Files;

import de.antonafanasjew.planettrip.tiled.Constants;
import de.antonafanasjew.planettrip.tiled.io.TiledMapIoException;
import de.antonafanasjew.planettrip.tiled.io.XmlTiledMapReader;
import de.antonafanasjew.planettrip.tiled.io.XmlTiledMapWriter;
import de.antonafanasjew.planettrip.tiled.processing.CleanRegionProcessor;
import de.antonafanasjew.planettrip.tiled.processing.CleanupTiledMapProcessor;
import de.antonafanasjew.planettrip.tiled.processing.CollisionProcessor;
import de.antonafanasjew.planettrip.tiled.processing.EdgeLayoutTiledMapProcessor;
import de.antonafanasjew.planettrip.tiled.processing.GridProcessor;
import de.antonafanasjew.planettrip.tiled.processing.IdentityProcessor;
import de.antonafanasjew.planettrip.tiled.processing.LayerDescriptorProvider;
import de.antonafanasjew.planettrip.tiled.processing.ManualOverrideTiledMapProcessor;
import de.antonafanasjew.planettrip.tiled.processing.ObjectsDistributorTiledMapProcessor;
import de.antonafanasjew.planettrip.tiled.processing.ResourceBasedCollisionRulesProvider;
import de.antonafanasjew.planettrip.tiled.processing.ResourceBasedLayoutRuleProvider;
import de.antonafanasjew.planettrip.tiled.processing.ResourceBasedManualOverrideRuleProvider;
import de.antonafanasjew.planettrip.tiled.processing.ResourceBasedObjectDistributionRuleProvider;
import de.antonafanasjew.planettrip.tiled.processing.ResourceBasedVerticalBuilderRuleProvider;
import de.antonafanasjew.planettrip.tiled.processing.ResourceBasedWaterplaceRulesProvider;
import de.antonafanasjew.planettrip.tiled.processing.ShiftLayerTiledMapProcessor;
import de.antonafanasjew.planettrip.tiled.processing.TileFinderProcessor;
import de.antonafanasjew.planettrip.tiled.processing.TiledMapProcessor;
import de.antonafanasjew.planettrip.tiled.processing.TilesetDescriptorProvider;
import de.antonafanasjew.planettrip.tiled.processing.VerticalBuilderTiledMapProcessor;
import de.antonafanasjew.planettrip.tiled.processing.WaterplaceProcessor;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;

public class StartTiledMapProcessing {

	private static Map<String, TiledMapProcessor> processorsByNames = Maps.newHashMap();
	
	
	//private static final String ALL_PROCESSORS_IN_CORRECT_ORDER = "objectscleanup,verticalbuilder,edges,manualoverride,objects,collision,waterplace,identity";
	private static final String ALL_PROCESSORS_IN_CORRECT_ORDER = "verticalbuilder,manualoverride,collision,waterplace,identity";
	
	static {
		try {
			processorsByNames.put("verticalbuilder", new VerticalBuilderTiledMapProcessor(new ResourceBasedVerticalBuilderRuleProvider()));
			processorsByNames.put("objects", new ObjectsDistributorTiledMapProcessor(new TilesetDescriptorProvider(), new LayerDescriptorProvider(), new ResourceBasedObjectDistributionRuleProvider(ResourceBasedObjectDistributionRuleProvider.PATH_TO_RULES_OBJECTS), false));
			processorsByNames.put("objectscleanup", new ObjectsDistributorTiledMapProcessor(new TilesetDescriptorProvider(), new LayerDescriptorProvider(), new ResourceBasedObjectDistributionRuleProvider(ResourceBasedObjectDistributionRuleProvider.PATH_TO_RULES_OBJECTS), true));
			processorsByNames.put("edges", new EdgeLayoutTiledMapProcessor(new ResourceBasedLayoutRuleProvider()));
			processorsByNames.put("manualoverride", new ManualOverrideTiledMapProcessor(new ResourceBasedManualOverrideRuleProvider()));
			processorsByNames.put("collision", new CollisionProcessor(new TilesetDescriptorProvider(), new LayerDescriptorProvider(), new ResourceBasedCollisionRulesProvider()));
			processorsByNames.put("waterplace", new WaterplaceProcessor(new TilesetDescriptorProvider(), new LayerDescriptorProvider(), new ResourceBasedWaterplaceRulesProvider()));
			processorsByNames.put("identity", new IdentityProcessor());
			processorsByNames.put("defaultregioncleaner", CleanRegionProcessor.createDefaultCleanerProcessor());
			processorsByNames.put("shiftrockobjects", new ShiftLayerTiledMapProcessor("Rocks_objects_passable", "Rocks_objects_manual", false));
			processorsByNames.put("suppliesgrid", new GridProcessor("Meta_Debug_Supplies_Grid", 40, 28, 33));
			processorsByNames.put("tempgrid", new GridProcessor("Meta_Debug_TempGrid", 20, 28, 33));
			processorsByNames.put("chartgrid", new GridProcessor("Meta_Debug_ChartGrid", 50, 28, 33));
			processorsByNames.put("watergrid", new GridProcessor("Meta_Debug_Water_Grid", 40, 28, 33));
			processorsByNames.put("findradar", new TileFinderProcessor(3060));
			processorsByNames.put("findbinoculars", new TileFinderProcessor(3061));
			processorsByNames.put("findweapons", new TileFinderProcessor(2385,2386,2387,2388,2389));
			processorsByNames.put("find_axe_pick_machete", new TileFinderProcessor(3065,3066,3067));
			processorsByNames.put("findarmor", new TileFinderProcessor(205));
			processorsByNames.put("findnotemptygrid", new TileFinderProcessor("Meta_Debug_TempGrid", 27, 32));
			processorsByNames.put("finderrortile", new TileFinderProcessor(1073744859));
			processorsByNames.put("cleanupErrorTile", new CleanupTiledMapProcessor(Lists.newArrayList(1073744859)));
			
		} catch (IOException|JDOMException e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
	
	public static void main(String[] args) throws TiledMapIoException, IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter comma separated processor names from the list: " + Joiner.on(",").join(processorsByNames.keySet()) + ",ALL");
		
		String input = br.readLine();
						
		System.out.println("Backing up");
		
		Files.copy(new File(Constants.MAP_FILE_NAME), new File(Constants.MAP_FILE_NAME + ".bak." + new GregorianCalendar().getTimeInMillis()));
		
		System.out.println("Reading map");
		
		XmlTiledMapReader reader = new XmlTiledMapReader(Constants.MAP_FILE_NAME);
		TiledMap map = reader.readTiledMap();
		
		input = input.equals("ALL") ? ALL_PROCESSORS_IN_CORRECT_ORDER : input;
		
		String[] processorNames = input.split(",");
		
		for (String processorName : processorNames) {
			
		
			System.out.println("Processing: " + processorName);
			
			TiledMapProcessor processor = processorsByNames.get(processorName);

			if (processor == null) {
				System.err.println("Processor not found: " + processorName);
				continue;
			}
			
			processor.process(map);
		}
		
		System.out.println("Writing map");
		
		XmlTiledMapWriter writer = new XmlTiledMapWriter(Constants.MAP_FILE_NAME);
		writer.writeTiledMap(map);
		
	}
	
}
