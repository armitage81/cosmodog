package de.antonafanasjew.planettrip.tiled.processingresources;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.google.common.base.Predicate;
import com.google.common.collect.Maps;

public class LayerDescriptors extends HashMap<String, LayerDescriptor> {

	private static final long serialVersionUID = 5403032453745460391L;
	
	public static final Predicate<Map.Entry<String,LayerDescriptor>> PREDICATE_NOT_TOPS_AND_NOT_METAS = new Predicate<Map.Entry<String,LayerDescriptor>>() {
		@Override
		public boolean apply(Entry<String, LayerDescriptor> entry) {
			LayerDescriptor descriptor = entry.getValue();
			return !descriptor.meta && ! descriptor.top;
		}
	};
	
	public static final Predicate<Map.Entry<String,LayerDescriptor>> PREDICATE_NOT_TIPS = new Predicate<Map.Entry<String,LayerDescriptor>>() {
		@Override
		public boolean apply(Entry<String, LayerDescriptor> entry) {
			LayerDescriptor descriptor = entry.getValue();
			return !descriptor.tip;
		}
	};
	
	public static final Predicate<Map.Entry<String,LayerDescriptor>> PREDICATE_NOT_TIPS_NOT_METAS = new Predicate<Map.Entry<String,LayerDescriptor>>() {
		@Override
		public boolean apply(Entry<String, LayerDescriptor> entry) {
			LayerDescriptor descriptor = entry.getValue();
			return !descriptor.tip && !descriptor.meta;
		}
	};
	

	public LayerDescriptors filter(Predicate<Map.Entry<String, LayerDescriptor>> predicate) {
		Map<String, LayerDescriptor> filtered = Maps.filterEntries(this, predicate);
		LayerDescriptors retVal = new LayerDescriptors();
		retVal.putAll(filtered);
		return retVal;
	}

}
