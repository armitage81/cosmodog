package de.antonafanasjew.planettrip.tiled.tiledmap;

import java.util.List;

import com.google.common.collect.Lists;

public class TiledObjectGroup {
	private String name;
	private List<TiledObject> objects = Lists.newArrayList();
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public List<TiledObject> getObjects() {
		return objects;
	}
	
	public void setObjects(List<TiledObject> objects) {
		this.objects = objects;
	}
	
	
	
}
