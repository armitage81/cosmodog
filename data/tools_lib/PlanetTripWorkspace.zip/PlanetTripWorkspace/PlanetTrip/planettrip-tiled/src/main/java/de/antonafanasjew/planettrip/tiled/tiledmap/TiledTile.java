package de.antonafanasjew.planettrip.tiled.tiledmap;

import de.antonafanasjew.planettrip.tiled.arithmetics.MarkableMatrixElement;


public class TiledTile implements MarkableMatrixElement {

	private int gid;

	private MarkableMatrixElement delegate;
	
	public int getGid() {
		return gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}
	
	public int getGidAsTileNumber() {
		return gid - 1;
	}

	public void setGidFromTileNumber(int tileNumber) {
		this.gid = tileNumber + 1;
	}

	@Override
	public boolean isMarked() {
		return delegate.isMarked();
	}

	@Override
	public Object getMark() {
		return delegate.getMark();
	}

	public MarkableMatrixElement getDelegate() {
		return delegate;
	}

	public void setDelegate(MarkableMatrixElement delegate) {
		this.delegate = delegate;
	}
	
}
