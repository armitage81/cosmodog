package de.antonafanasjew.planettrip.tiled.processing;

public interface ResourceProvider<T> {

	public T provideResource(String resourcePath);
	
}
