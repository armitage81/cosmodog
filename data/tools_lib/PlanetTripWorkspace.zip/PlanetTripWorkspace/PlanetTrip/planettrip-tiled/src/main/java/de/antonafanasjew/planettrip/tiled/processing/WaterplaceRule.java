package de.antonafanasjew.planettrip.tiled.processing;

import java.util.Set;

import com.google.common.collect.Sets;

public class WaterplaceRule {
	
	public static final String WATERPLACE_TYPE_DRINKABLE = "drinkable";
	
	//f.i. drinkable
	public String type;
	public String markerLayer;
	public int waterMarkerTileNumber;
	public int closeToWaterMarkerTileNumber;
	public String description;
	public Set<String> tilesetReferences = Sets.newHashSet();
	public Set<String> ignoreTilesetReferences = Sets.newHashSet();
}
