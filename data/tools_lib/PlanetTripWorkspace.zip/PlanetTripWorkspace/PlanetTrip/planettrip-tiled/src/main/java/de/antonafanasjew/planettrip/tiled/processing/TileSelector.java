package de.antonafanasjew.planettrip.tiled.processing;

import java.util.Map;

import com.google.common.collect.Maps;


public class TileSelector {
	
	public Map<Integer, Float> candidates = Maps.newHashMap();
	
	public Integer selectAtRandom() {
		
		float sum = 0;
		
		for (Float weight : candidates.values()) {
			sum += weight;
		}
		
		int randomKey = -1;
		double random = Math.random() * sum;
		for (Map.Entry<Integer, Float> candidate : candidates.entrySet()) {
		    random -= candidate.getValue();
		    if (random <= 0.0d)
		    {
		    	randomKey = candidate.getKey();
		        break;
		    }
		}
		
		return randomKey;
	}
	
}


