package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;

import org.jdom2.Element;

import de.antonafanasjew.planettrip.tiled.processingresources.LayerDescriptor;
import de.antonafanasjew.planettrip.tiled.processingresources.LayerDescriptors;

public class LayerDescriptorProvider extends AbstractResourceProvider<LayerDescriptors> {

	@Override
	protected LayerDescriptors resourceFromRootElement(Element root) {
		LayerDescriptors retVal = new LayerDescriptors();
		
		List<Element> layerElements = root.getChildren("layer");
		
		for (Element layerElement : layerElements) {
			LayerDescriptor layerDescriptor = new LayerDescriptor();
			layerDescriptor.name = layerElement.getAttributeValue("name");
			layerDescriptor.top = Boolean.parseBoolean(layerElement.getAttributeValue("top"));
			layerDescriptor.tip = Boolean.parseBoolean(layerElement.getAttributeValue("tip"));
			layerDescriptor.meta = Boolean.parseBoolean(layerElement.getAttributeValue("meta"));
			layerDescriptor.alt = Boolean.parseBoolean(layerElement.getAttributeValue("alt"));
			retVal.put(layerDescriptor.name, layerDescriptor);
		}
		
		return retVal;
	}

}
