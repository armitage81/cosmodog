package de.antonafanasjew.planettrip.tiled.tiledmap;

import de.antonafanasjew.planettrip.tiled.arithmetics.MarkableMatrixElement;
import de.antonafanasjew.planettrip.tiled.processing.LayoutRule;

public class TileMarker implements MarkableMatrixElement {

	private TiledTile tile;
	private LayoutRule edgeRule;

	public TileMarker(TiledTile tile, LayoutRule edgeRule) {
		this.tile = tile;
		this.edgeRule = edgeRule;
	}
	
	@Override
	public boolean isMarked() {
		return edgeRule.tileSelector.candidates.keySet().contains(this.tile.getGidAsTileNumber());
	}

	@Override
	public Object getMark() {
		return this.tile.getGidAsTileNumber();
	}
	
}
