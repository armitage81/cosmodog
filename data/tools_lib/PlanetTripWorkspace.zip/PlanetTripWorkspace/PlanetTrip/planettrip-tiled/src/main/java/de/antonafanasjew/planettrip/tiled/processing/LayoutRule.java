package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;
import java.util.Map;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;

import de.antonafanasjew.planettrip.tiled.arithmetics.MatrixNeighbourhood;

public class LayoutRule {
	public String tileName;
	public TileSelector tileSelector;
	public Map<MatrixNeighbourhood, TileSelector> edgeTileNumbers = Maps.newHashMap();
	public List<Integer> tileNumbersNoOverride = Lists.newArrayList();
	public Multimap<String, Integer> lockedRegions = ArrayListMultimap.create();
}

