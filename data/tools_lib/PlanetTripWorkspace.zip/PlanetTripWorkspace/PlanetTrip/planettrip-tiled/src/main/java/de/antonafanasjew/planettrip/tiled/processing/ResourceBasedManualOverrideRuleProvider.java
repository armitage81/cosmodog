package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

import com.google.common.collect.Lists;

public class ResourceBasedManualOverrideRuleProvider implements ManualOverrideRuleProvider {

	@Override
	public ManualOverrideRules provideManualOverrideRules() throws JDOMException, IOException {
		
		ManualOverrideRules retVal = new ManualOverrideRules();
		
		InputStream resourceStream = EdgeLayoutTiledMapProcessor.class.getClassLoader().getResourceAsStream("de/antonafanasjew/planettrip/tiled/manualoverride.rules");
        SAXBuilder jdomBuilder = new SAXBuilder();
        Document jdomDocument = jdomBuilder.build(resourceStream);
  
        Element root = jdomDocument.getRootElement();
        
        List<Element> layerElements = root.getChildren("layer");
        
        for (Element layerElement : layerElements) {
        	List<ManualOverrideRule> rules = rulesFromLayerElement(layerElement);
        	retVal.addAll(rules);
        }
        
        return retVal;
        		
	}
	
	private List<ManualOverrideRule> rulesFromLayerElement(Element layerElement) {
		
		List<ManualOverrideRule> retVal = Lists.newArrayList();
		
		String layerName = layerElement.getAttribute("name").getValue();
		String regionLayerName = layerElement.getAttribute("regionLayerName").getValue();
		int regionTileId = Integer.parseInt(layerElement.getAttribute("regionTileId").getValue());
		
		List<Element> overrideElements = layerElement.getChildren("override");
		
		for (Element overrideElement : overrideElements) {
			
			int tileId = Integer.parseInt(overrideElement.getAttribute("tileId").getValue());
			int replacementTileId = Integer.parseInt(overrideElement.getAttribute("replacementTileId").getValue());
			
			ManualOverrideRule rule = new ManualOverrideRule();
			rule.overrideLayerName = layerName;
			rule.regionLayerName = regionLayerName;
			rule.regionTileId = regionTileId;
			rule.originalTileId = tileId;
			rule.replacementTileId = replacementTileId;
			
			retVal.add(rule);
			
		}
		
		return retVal;
	}
	
	
	
	
	public static void main(String[] args) throws IOException, JDOMException {
		ResourceBasedManualOverrideRuleProvider p = new ResourceBasedManualOverrideRuleProvider();
		ManualOverrideRules rules = p.provideManualOverrideRules();
		System.out.println(rules);
	}

}
