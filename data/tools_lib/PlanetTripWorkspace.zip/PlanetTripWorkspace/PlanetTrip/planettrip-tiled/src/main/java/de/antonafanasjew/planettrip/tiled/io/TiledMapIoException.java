package de.antonafanasjew.planettrip.tiled.io;

public class TiledMapIoException extends Exception {

	private static final long serialVersionUID = -7396411306734643643L;
	
	public TiledMapIoException(String message, Throwable cause) {
		super(message, cause);
	}
}
