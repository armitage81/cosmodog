package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import de.antonafanasjew.planettrip.tiled.processingresources.LayerDescriptors;
import de.antonafanasjew.planettrip.tiled.processingresources.TilesetDescriptors;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.util.Matrix;

public class ObjectsDistributorTiledMapProcessor extends AbstractTiledMapProcessor {

	private ObjectDistributionRules rules = null;
	private LayerDescriptors layerDescriptors;
	private boolean onlyCleanup = false;
	
	public ObjectsDistributorTiledMapProcessor(ResourceProvider<TilesetDescriptors> tilesetProvider, LayerDescriptorProvider layerDescriptorProvider, ObjectDistributionRuleProvider ruleProvider, boolean onlyCleanup) throws IOException {
		this.rules = ruleProvider.provideObjectDistributionRules();
		layerDescriptors = layerDescriptorProvider.provideResource("de/antonafanasjew/planettrip/tiled/layers.resource");
		this.onlyCleanup = onlyCleanup;
	}
	
	@Override
	public void process(TiledMap tiledMap) {

		System.out.println("Starting object distribution");
		
		Random r = new Random(1);
		
		Map<String, TiledMapLayer> layerByNameCache = Maps.newHashMap();
		Map<Integer, TiledMapLayer> layerByNumberCache = Maps.newHashMap();
		
		List<Matrix<TiledTile>> allLayersTiles = Lists.newArrayList();
		
		int layerNumber = 0;
		for (TiledMapLayer l : tiledMap.getMapLayers()) {
			layerByNameCache.put(l.getName(), l);
			layerByNumberCache.put(layerNumber, l);
			allLayersTiles.add(l.getDataAsMatrix());
			layerNumber++;
		}
		
		LayerDescriptors nonTipsNonMetaLayerDescriptors = layerDescriptors.filter(LayerDescriptors.PREDICATE_NOT_TIPS_NOT_METAS);
		
		layerNumber = 0;
		for (TiledMapLayer layer : tiledMap.getMapLayers()) {
						
			System.out.println("Decorating layer " + layer.getName());
			
			Matrix<TiledTile> layerTiles = layer.getDataAsMatrix();

			int count = 0;

			for (ObjectDistributionRule rule : rules) {
			
				//Skip rules that don't belong to this layer
				if (rule.layer.equals(layer.getName()) == false) {
					continue;
				}
				
				for (int k = 0; k < layerTiles.w; k++) {
					for (int l = 0; l < layerTiles.h; l++) {
						TiledTile tile = layerTiles.getElement(k, l);
						if (tile.getGidAsTileNumber() == rule.tileNumber) {
							tile.setGid(0);
						}
					}
				}
				
				//Don't process with the distribution if it is cleanup only.
				if (onlyCleanup) {
					continue;
				}
				
				String undergroundLayer = rule.undergroundLayer;
				
				TiledMapLayer underground = layerByNameCache.get(undergroundLayer);
				
				Matrix<TiledTile> undergroundTiles = underground.getDataAsMatrix();
				
				for (int k = 0; k < layerTiles.w; k++) {
					for (int l = 0; l < layerTiles.h; l++) {
	
						TiledTile tile = layerTiles.getElement(k, l);
						TiledTile undergroundTile = undergroundTiles.getElement(k, l);
	
						//Ignore the tile if the underground does not fit.
						if (rule.undergroundTileNumbers.contains(undergroundTile.getGidAsTileNumber()) == false) {
							continue;
						}
						
						//Ignore the tile if it is not empty already or if one of the higher layers has a non-empty tile on this place.
						//In case of some layers, the layer above can be ignored (Flowers tips, f.i.). So layers containing 'tips' in the name will still be taken into account
						//even if they are not empty.
						boolean breakIt = false;
						for (int m = layerNumber; m < tiledMap.getMapLayers().size(); m++) {
							String layerName = tiledMap.getMapLayers().get(m).getName();
							TiledTile higherLayerTile = allLayersTiles.get(m).getElement(k, l);
							if (higherLayerTile.getGid() != 0 &&  nonTipsNonMetaLayerDescriptors.containsKey(layerName)) {
								breakIt = true;
								break;
							}
						}
						
						if (breakIt) {
							continue;
						}
						
						float percentage = rule.weight;
						
						boolean doIt = r.nextFloat() < percentage;
						
						if (doIt) {
							tile.setGidFromTileNumber(rule.tileNumber);
						}

					}
				}
			}
			layerNumber++;
			System.out.println("Distributed " + count + " objects for layer " + layer.getName());
		}
		System.out.println("Object distribution complete");
		
	}

}
