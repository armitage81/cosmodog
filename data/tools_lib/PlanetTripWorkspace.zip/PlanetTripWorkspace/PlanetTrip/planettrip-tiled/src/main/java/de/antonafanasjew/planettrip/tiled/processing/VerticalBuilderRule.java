package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;

import com.google.common.collect.Lists;

public class VerticalBuilderRule {
	public String layer1;
	public String layer2;
	public List<Integer> layer1TileNumbers = Lists.newArrayList();
	public List<Integer> layer2TileNumbers = Lists.newArrayList();
}
