package de.antonafanasjew.planettrip.tiled.processing;

import java.util.ArrayList;

public class CollisionRules extends ArrayList<CollisionRule> {

	private static final long serialVersionUID = 4578095100521992349L;

}
