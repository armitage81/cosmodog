package de.antonafanasjew.planettrip.tiled.processing;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;

/**
 * Returning the same map without processing it.
 * Can be useful to shorten up the test when only reading and writing of the map are interesting. 
 */
public class IdentityProcessor extends AbstractTiledMapProcessor {

	@Override
	public void process(TiledMap tiledMap) {
		System.out.println("Starting identity processor (Not actually doing anything)");
		System.out.println("Finished identity processor (Map hasn't been changed)");
	}

}
