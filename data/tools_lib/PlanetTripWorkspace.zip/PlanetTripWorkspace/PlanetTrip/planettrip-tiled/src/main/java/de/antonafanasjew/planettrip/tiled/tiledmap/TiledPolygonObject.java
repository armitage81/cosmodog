package de.antonafanasjew.planettrip.tiled.tiledmap;

public class TiledPolygonObject extends TiledLineObject {

}
