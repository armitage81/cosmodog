package de.antonafanasjew.planettrip.tiled.tiledmap;

import java.util.List;

public class TiledMap {

	private String version;
	private String orientation;
	private String renderorder;
	private int width;
	private int height;
	private int tileWidth;
	private int tileHeight;
	private int nextObjectId;
	private Tileset tileset;
	private List<TiledMapLayer> mapLayers;
	private List<TiledObjectGroup> objectGroups;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	
	public String getOrientation() {
		return orientation;
	}
	
	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}
	
	public String getRenderorder() {
		return renderorder;
	}
	
	public void setRenderorder(String renderorder) {
		this.renderorder = renderorder;
	}
	
	public int getWidth() {
		return width;
	}
	
	public void setWidth(int width) {
		this.width = width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void setHeight(int height) {
		this.height = height;
	}
	
	public int getTileWidth() {
		return tileWidth;
	}
	
	public void setTileWidth(int tileWidth) {
		this.tileWidth = tileWidth;
	}
	
	public int getTileHeight() {
		return tileHeight;
	}
	
	public void setTileHeight(int tileHeight) {
		this.tileHeight = tileHeight;
	}
	
	public int getNextObjectId() {
		return nextObjectId;
	}
	
	public void setNextObjectId(int nextObjectId) {
		this.nextObjectId = nextObjectId;
	}
	
	public Tileset getTileset() {
		return tileset;
	}
	
	public void setTileset(Tileset tileset) {
		this.tileset = tileset;
	}
	
	public List<TiledMapLayer> getMapLayers() {
		return mapLayers;
	}
	
	public void setMapLayers(List<TiledMapLayer> mapLayers) {
		this.mapLayers = mapLayers;
	}

	public List<TiledObjectGroup> getObjectGroups() {
		return objectGroups;
	}

	public void setObjectGroups(List<TiledObjectGroup> objectGroups) {
		this.objectGroups = objectGroups;
	}

}
