package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;

import org.jdom2.Element;

public class ResourceBasedCollisionRulesProvider extends AbstractResourceProvider<CollisionRules> implements ResourceProvider<CollisionRules> {

	@Override
	protected CollisionRules resourceFromRootElement(Element root) {
		
		CollisionRules retVal = new CollisionRules();
		
		List<Element> collisionElements = root.getChildren("collision");
		
		for (Element collisionElement : collisionElements) {
			retVal.add(collisionRuleFromElement(collisionElement));
		}
		
		return retVal;
	}

	private CollisionRule collisionRuleFromElement(Element collisionElement) {
		CollisionRule retVal = new CollisionRule();
		
		retVal.description = collisionElement.getAttributeValue("description");
		retVal.type = collisionElement.getAttributeValue("type");
		retVal.markerTileNumber = Integer.parseInt(collisionElement.getAttributeValue("markerTileNumber"));
		retVal.markerLayer = collisionElement.getAttributeValue("markerLayer");
		
		List<Element> tilesetRefElements = collisionElement.getChildren("tileset-ref");
		
		for (Element tilesetRefElement : tilesetRefElements) {
			String group = tilesetRefElement.getAttributeValue("group");
			retVal.tilesetReferences.add(group);
		}
		
		Element ignoreElement = collisionElement.getChild("ignore");
		if (ignoreElement != null) {
			List<Element> ignoreTilesetRefElements = ignoreElement.getChildren("tileset-ref");
			for (Element ignoreTilesetRefElement : ignoreTilesetRefElements) {
				String group = ignoreTilesetRefElement.getAttributeValue("group");
				retVal.ignoreTilesetReferences.add(group);
			}
		}
		
		return retVal;
	}

}
