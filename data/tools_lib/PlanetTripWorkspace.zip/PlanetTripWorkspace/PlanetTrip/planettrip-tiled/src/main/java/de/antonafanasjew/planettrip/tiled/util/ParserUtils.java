package de.antonafanasjew.planettrip.tiled.util;

import java.text.ParseException;
import java.util.Set;
import java.util.regex.Pattern;

import com.google.common.collect.Sets;

import de.antonafanasjew.planettrip.tiled.processingresources.TilesetDescriptor;

public class ParserUtils {

	/**
	 * First calculates all numbers from the range representation. Then adds additional numbers based on the range type.
	 * 
	 */
	public static Set<Integer> parseIntegerSetFromTextAndRangeType(String text, String rangeType) throws ParseException {
		Set<Integer> numbers = parseIntegerSetFromText(text);
		Set<Integer> retVal = Sets.newHashSet();
		for (int number : numbers) {
			Set<Integer> allAdditionalNumbers = addNumbersForRangeType(number, rangeType);
			retVal.addAll(allAdditionalNumbers);
		}
		return retVal;
	}
	
	private static Set<Integer> addNumbersForRangeType(int number, String rangeType) {
		
		Set<Integer> retVal = Sets.newHashSet();
		
		if (TilesetDescriptor.TYPE_TILESET.equals(rangeType)) {
			retVal.add(number);
		} else if (TilesetDescriptor.TYPE_CONVENTION_BORDER_CONCAV_INNER.equals(rangeType)) {
			retVal.add(number - 4);
			retVal.add(number - 2);
			retVal.add(number + 2);
			retVal.add(number + 4);
		} else if (TilesetDescriptor.TYPE_CONVENTION_BORDER_CONCAV_OUTER.equals(rangeType)) {
			retVal.add(number - 4);
			retVal.add(number - 2);
			retVal.add(number + 2);
			retVal.add(number + 4);
		} else if (TilesetDescriptor.TYPE_CONVENTION_BORDER_CONVEX.equals(rangeType)) {
			retVal.add(number + 1);
			retVal.add(number + 2);
			retVal.add(number + 3);
			retVal.add(number + 4);
			retVal.add(number + 5);
			retVal.add(number + 6);
			retVal.add(number + 7);
			retVal.add(number + 8);
		} else if (TilesetDescriptor.TYPE_CONVENTION_CONCAV_OUTER.equals(rangeType)) {
			retVal.add(number - 4);
			retVal.add(number - 2);
			retVal.add(number + 2);
			retVal.add(number + 4);
		} else if (TilesetDescriptor.TYPE_CONVENTION_CONCAV_INNER.equals(rangeType)) {
			retVal.add(number - 4);
			retVal.add(number - 2);
			retVal.add(number + 2);
			retVal.add(number + 4);
		} else if (TilesetDescriptor.TYPE_CONVENTION_CONVEX.equals(rangeType)) {
			retVal.add(number);
			retVal.add(number + 1);
			retVal.add(number + 2);
			retVal.add(number + 3);
			retVal.add(number + 4);
			retVal.add(number + 5);
			retVal.add(number + 6);
			retVal.add(number + 7);
			retVal.add(number + 8);
		}
		
		return retVal;
	}

	/**
	 * Returns a set of unique integers described by a string in form "1,2,5,10-14,3,5-16,1"
	 * Ranges are inclusive on both ends.
	 * Spaces are allowed before and after separators
	 * Note: this parser is only for positive natural numbers (and 0)
	 */
	public static Set<Integer> parseIntegerSetFromText(String text) throws ParseException {
		Pattern p = Pattern.compile("[0-9]+(\\s*-\\s*[0-9]+)?(\\s*,\\s*[0-9]+(\\s*-\\s*[0-9]+)?)*");
		if (!p.matcher(text).matches()) {
			throw new ParseException("Could not parse integer set from text " + text, 0);
		}
		
		Set<Integer> retVal = Sets.newHashSet();
		
		String[] rangeRepresentations = text.split(",");
		
		for (String rangeRepresentation : rangeRepresentations) {
			Set<Integer> range = rangeFromRepresentation(rangeRepresentation.trim());
			retVal.addAll(range);
		}
		
		return retVal;
	}

	private static Set<Integer> rangeFromRepresentation(String rangeRepresentation) throws ParseException {
		Set<Integer> retVal = Sets.newHashSet();
		
		if (rangeRepresentation.contains("-")) {
			String[] minMaxRepresentations = rangeRepresentation.split("-");
			int min = Integer.parseInt(minMaxRepresentations[0].trim());
			int max = Integer.parseInt(minMaxRepresentations[1].trim());
			for (int i = min; i <= max; i++) {
				retVal.add(i);
			}
		} else {
			retVal.add(Integer.parseInt(rangeRepresentation));
		}
		
		return retVal;
	}
	
	public static void main(String[] args) throws ParseException {
		System.out.println(parseIntegerSetFromText("1,2,3"));
		System.out.println(parseIntegerSetFromText("1,2,3-5"));
		System.out.println(parseIntegerSetFromText("1-10,2-5,5,6,7"));
		System.out.println(parseIntegerSetFromText("1-1"));
		System.out.println(parseIntegerSetFromText("4-7"));
		System.out.println(parseIntegerSetFromText("4-7      ,       9"));
		System.out.println(parseIntegerSetFromText("4    -    7      ,       9"));
		System.out.println(parseIntegerSetFromTextAndRangeType("0", "CONVENTION_CONVEX"));
	}
	
}
