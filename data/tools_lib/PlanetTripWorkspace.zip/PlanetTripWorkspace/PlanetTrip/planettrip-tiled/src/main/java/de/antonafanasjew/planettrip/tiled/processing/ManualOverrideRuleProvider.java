package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;

import org.jdom2.JDOMException;

public interface ManualOverrideRuleProvider {

	public ManualOverrideRules provideManualOverrideRules() throws JDOMException, IOException;
}
