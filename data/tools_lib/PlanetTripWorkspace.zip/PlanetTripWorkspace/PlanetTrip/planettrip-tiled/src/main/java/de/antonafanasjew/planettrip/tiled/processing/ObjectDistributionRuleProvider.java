package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;

public interface ObjectDistributionRuleProvider {
	public ObjectDistributionRules provideObjectDistributionRules() throws IOException;
}
