package de.antonafanasjew.planettrip.tiled.processing;

public interface LayoutRuleProvider {

	public LayoutRules provideLayoutRules();
	
}
