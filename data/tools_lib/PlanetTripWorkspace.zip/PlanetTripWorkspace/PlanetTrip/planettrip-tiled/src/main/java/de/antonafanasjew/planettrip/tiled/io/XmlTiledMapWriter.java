package de.antonafanasjew.planettrip.tiled.io;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Text;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import com.badlogic.gdx.utils.Base64Coder;
import com.google.common.base.Joiner;

import de.antonafanasjew.planettrip.tiled.tiledmap.TileImage;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledEllipseObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledFigureObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledLineObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledLineObject.Point;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledObjectGroup;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledPolygonObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTileObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.Tileset;

public class XmlTiledMapWriter implements TiledMapWriter {

	private String fileName;
	
	public XmlTiledMapWriter(String fileName) {
		this.fileName = fileName;
	}
	
	@Override
	public void writeTiledMap(TiledMap tiledMap) throws TiledMapIoException {
		
		FileWriter fw = null;
		
		try {
			Element root = toElement(tiledMap);
			Document doc = new Document(root);
	 
			XMLOutputter xmlOutput = new XMLOutputter();
	 
			xmlOutput.setFormat(Format.getPrettyFormat());
			fw = new FileWriter(fileName);
			xmlOutput.output(doc, fw);
		} catch (IOException e) {
			throw new TiledMapIoException(e.getMessage(), e);
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e) {
				}
			}
		}
	}
	
//	private Element toElement(TiledTile tile) {
//		Element element = new Element("tile");
//		element.setAttribute("gid", String.valueOf(tile.getGid()));
//		return element;
//	}
	
	private Element toElement(TiledMapLayer layer) throws IOException {
		
		Element layerElement = new Element("layer");

		layerElement.setAttribute("name", layer.getName());
		layerElement.setAttribute("width", String.valueOf(layer.getWidth()));
		layerElement.setAttribute("height", String.valueOf(layer.getHeight()));
		layerElement.setAttribute("opacity", String.valueOf(layer.getOpacity()));
		
		Element dataElement = toElement(layer.getData());
		
//		for (TiledTile tile : layer.getData()) {
//			dataElement.addContent(toElement(tile));
//		}
		
		layerElement.addContent(dataElement);
		return layerElement;
	}
	
	private Element toElement(List<TiledTile> data) throws IOException {
		
		Element retVal = new Element("data");

		retVal.setAttribute("encoding", "base64");
		retVal.setAttribute("compression", "gzip");

		byte[] dataBytes = new byte[data.size() * 4];
		
		for (int i = 0; i < data.size(); i++) {
			TiledTile tile = data.get(i);
			int gid = tile.getGid();
			byte[] gidBytes = new byte[] {(byte)gid, (byte)(gid >>> 8), (byte)(gid >>> 16), (byte)(gid >>> 24)};
			
			for (int j = 0; j < gidBytes.length; j++) {
				dataBytes[i * 4 + j] = gidBytes[j];
			}
		}
		
		
		ByteArrayOutputStream out = new ByteArrayOutputStream();
	    GZIPOutputStream gz = new GZIPOutputStream(out);
	    ByteArrayInputStream in = new ByteArrayInputStream(dataBytes);
	    int c;
	    while ((c = in.read()) != -1) {
	    	gz.write(c);
	    }
	    gz.finish();
	    
		byte[] compressedBytes = out.toByteArray();
		String encodedData = new String(Base64Coder.encode(compressedBytes));
		
		retVal.addContent(new Text(encodedData));
		
		return retVal;
	}

	private Element toElement(TileImage image) {
		Element element = new Element("image");
		element.setAttribute("source", image.getSource());
		element.setAttribute("width", String.valueOf(image.getWidth()));
		element.setAttribute("height", String.valueOf(image.getHeight()));
		return element;
	}

	private Element toElement(Tileset tileset) {
		Element element = new Element("tileset");
		
		element.setAttribute("firstgid", String.valueOf(tileset.getFirstgid()));
		element.setAttribute("name", tileset.getName());
		element.setAttribute("tilewidth", String.valueOf(tileset.getTilewidth()));
		element.setAttribute("tileheight", String.valueOf(tileset.getTileheight()));
		element.addContent(toElement(tileset.getTileImage()));
		
		return element;
	}
	
	
	private Element toElement(TiledObjectGroup objectGroup) {
		
		Element objectGroupElement = new Element("objectgroup");
		objectGroupElement.setAttribute("width", "1"); //For some reason, the application parsing the resulting map requires these two parameters, so we set them here for convenience.
		objectGroupElement.setAttribute("height", "1");
		String name = objectGroup.getName();
		if (name != null) {
			objectGroupElement.setAttribute("name", name);
		}
		
		for (TiledObject tiledObject : objectGroup.getObjects()) {
			objectGroupElement.addContent(toElement(tiledObject));
		}
		
		return objectGroupElement;
	}
	
	
	private Element toElement(TiledObject tiledObject) {
		Element objectElement = new Element("object");
		
		objectElement.setAttribute("width", "1"); //For some reason, the application parsing the resulting map requires these two parameters, so we set them here for convenience.
		objectElement.setAttribute("height", "1");
		
		objectElement.setAttribute("id", String.valueOf(tiledObject.getId()));
		objectElement.setAttribute("x", String.valueOf((int)tiledObject.getX()));
		objectElement.setAttribute("y", String.valueOf((int)tiledObject.getY()));
		
		if (tiledObject.getName() != null) {
			objectElement.setAttribute("name", tiledObject.getName());
		}
		
		if (tiledObject.getType() != null) {
			objectElement.setAttribute("type", tiledObject.getType());
		}
		
		Map<String, String> properties = tiledObject.getProperties();
		if (properties.isEmpty() == false) {
			Element propertiesElement = new Element("properties");
			for (String propertyName : properties.keySet()) {
				Element propertyElement = new Element("property");
				propertyElement.setAttribute("name", propertyName);
				propertyElement.setAttribute("value", properties.get(propertyName));
				propertiesElement.addContent(propertyElement);
			}
			objectElement.addContent(propertiesElement);
		}
		
		if (tiledObject instanceof TiledFigureObject) {
			
			TiledFigureObject tfo = (TiledFigureObject)tiledObject;
			
			objectElement.setAttribute("width", String.valueOf((int)tfo.getWidth()));
			objectElement.setAttribute("height", String.valueOf((int)tfo.getHeight()));
		}
		
		if (tiledObject instanceof TiledEllipseObject) {
			objectElement.addContent(new Element("ellipse"));
		}
		
		if (tiledObject instanceof TiledTileObject) {
			objectElement.setAttribute("gid", String.valueOf(((TiledTileObject)tiledObject).getGid()));
		}
		
		if (tiledObject instanceof TiledLineObject) {
			TiledLineObject tlo = (TiledLineObject)tiledObject;
			List<Point> points = tlo.getPoints();	
			String pointsAttributeValue = Joiner.on(" ").join(points);			
			String lineBasedElementName = tiledObject instanceof TiledPolygonObject ? "polygon" : "polyline";
			Element lineBasedElement = new Element(lineBasedElementName);
			lineBasedElement.setAttribute("points", pointsAttributeValue);
			objectElement.addContent(lineBasedElement);
			
		}
		
		
		return objectElement;
	}

	private Element toElement(TiledMap map) throws IOException {
		Element element = new Element("map");
		
		element.setAttribute("version", map.getVersion());
		element.setAttribute("orientation", map.getOrientation());
		element.setAttribute("renderorder", map.getRenderorder());
		element.setAttribute("width", String.valueOf(map.getWidth()));
		element.setAttribute("height", String.valueOf(map.getHeight()));
		element.setAttribute("tilewidth", String.valueOf(map.getTileWidth()));
		element.setAttribute("tileheight", String.valueOf(map.getTileHeight()));
		element.setAttribute("nextobjectid", String.valueOf(map.getNextObjectId()));
		
		element.addContent(toElement(map.getTileset()));
		
		for (TiledMapLayer layer : map.getMapLayers()) {
			element.addContent(toElement(layer));
		}
		
		for (TiledObjectGroup objectGroup : map.getObjectGroups()) {
			element.addContent(toElement(objectGroup));
		}
		
		
		return element;
	}
}
