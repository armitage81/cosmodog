package de.antonafanasjew.planettrip.tiled.tiledmap;

import java.util.List;

import de.antonafanasjew.planettrip.util.Matrix;

public class TiledMapLayer {

	private String name;
	private int width;
	private int height;
	private float opacity;
	private List<TiledTile> data;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getWidth() {
		return width;
	}
	
	public void setWidth(int width) {
		this.width = width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void setHeight(int height) {
		this.height = height;
	}

	public List<TiledTile> getData() {
		return data;
	}

	public void setData(List<TiledTile> data) {
		this.data = data;
	}
	
	public Matrix<TiledTile> getDataAsMatrix() {
		
		TiledTile[][] dataAsMatrix = new TiledTile[width][height];
		int x = 0;
		int y = 0;
		for (int i = 0; i < width * height; i++) {
			dataAsMatrix[x][y] = data.get(i);
			x++;
			if (x >= width) {
				x = 0;
				y++;
			}
		}
		
		Matrix<TiledTile> matrix = new Matrix<TiledTile>(dataAsMatrix);
		return matrix;
	}

	public float getOpacity() {
		return opacity;
	}

	public void setOpacity(float opacity) {
		this.opacity = opacity;
	}
	
}
