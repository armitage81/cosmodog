package de.antonafanasjew.planettrip.tiled.arithmetics;

public enum MatrixNeighbourhood {
	
	none(new short[]{0}),
	west(new short[]{128,129,192,193}),
	northWest(new short[]{64}),
	north(new short[]{32, 48, 96, 112}),
	northEast(new short[]{16}),
	east(new short[]{8,12,24,28}),
	southEast(new short[]{4}),
	south(new short[]{2,3,6,7}),
	southWest(new short[]{1}),
	
	northAndWest(new short[]{160, 161, 176, 177, 224, 225, 240, 241}),
	northAndEast(new short[]{40, 44, 56, 60, 104, 108, 120, 124}),
	southAndEast(new short[]{10, 11, 14, 15, 26, 27, 30, 31}),
	southAndWest(new short[]{130, 131, 134, 135, 194, 195, 198, 199});

	private short[] neighbourhoodIds;
	
	private MatrixNeighbourhood(short[] neighbourhoodIds) {
		this.neighbourhoodIds = neighbourhoodIds;
	}

	public short[] getNeighbourhoodIds() {
		return neighbourhoodIds;
	}
	
	public static MatrixNeighbourhood getByNeighbourhoodId(short neighbourhoodId) throws UnknownNeighbourhoodException {
		for (MatrixNeighbourhood neighbourhood : MatrixNeighbourhood.values()) {
			for (short knownNeighbourHoodId : neighbourhood.getNeighbourhoodIds()) {
				if (knownNeighbourHoodId == neighbourhoodId) {
					return neighbourhood;
				}
			}
		}
		throw new UnknownNeighbourhoodException("Unknown neighbourhood id " + neighbourhoodId);
	}
}
