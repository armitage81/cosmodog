package de.antonafanasjew.planettrip.tiled.arithmetics;

public class UnknownNeighbourhoodException extends Exception {

	private static final long serialVersionUID = 2125164667845913261L;
	
	public UnknownNeighbourhoodException(String s) {
		super(s);
	}

}
