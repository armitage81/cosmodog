package de.antonafanasjew.planettrip.tiled.processing;

import java.util.List;
import java.util.Map;

import antonafanasjew.cosmodog.topology.PlacedRectangle;
import antonafanasjew.cosmodog.util.CollisionUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledObject;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledObjectGroup;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.util.Matrix;

public class CleanRegionProcessor extends AbstractTiledMapProcessor {

	public static final String DEFAULT_CLEANER_REGION_GROUP_NAME = "CLEANER";
	public static final String DEFAULT_CLEANER_REGION_NAME = "CLEANER_REGION";
	
	private String cleanerRegionsObjectGroupName;
	private List<String> cleanerRegionNames = Lists.newArrayList();
	private List<String> cleanerLayersNames = Lists.newArrayList();
		
	private boolean ignoreCleanerLayersNamesAndCleanAll;
	
	public static CleanRegionProcessor createDefaultCleanerProcessor() {
		CleanRegionProcessor instance = new CleanRegionProcessor();
		instance.setCleanerRegionsObjectGroupName(DEFAULT_CLEANER_REGION_GROUP_NAME);
		instance.getCleanerRegionNames().add(DEFAULT_CLEANER_REGION_NAME);
		instance.setIgnoreCleanerLayersNamesAndCleanAll(true);
		return instance;
	};
	
	@Override
	public void process(TiledMap tiledMap) {
		
		System.out.println("Starting region cleaner processor");
		
		//Find the correct object group.
		TiledObjectGroup group = null;
		
		for (TiledObjectGroup oneGroup : tiledMap.getObjectGroups()) {
			if (oneGroup.getName().equals(cleanerRegionsObjectGroupName)) {
				group = oneGroup;
			}
		}
		
		System.out.println("Searching for the cleaner region group: " + cleanerRegionsObjectGroupName);
		
		//Finish processing if no object group found.
		if (group == null) {
			System.out.println("Region cleaner group not found. Exiting the cleaner processor.");
			return;
		}
		
		System.out.println("Cleaner region group found. Starting cleaner region iteration.");
		
		//Prepare all objects in a map.
		Map<String, TiledObject> objects = Maps.newHashMap();
		
		for (TiledObject object : group.getObjects()) {
			objects.put(object.getName(), object);
		}
		
		//Iterate through all given regions that need to be cleaned
		for (String cleanerRegionName : cleanerRegionNames) {
			
			System.out.println("-Searching the cleaner region: " + cleanerRegionName);
			
			TiledObject cleanerRegion = objects.get(cleanerRegionName);
			
			if (cleanerRegion == null) {
				System.out.println("-Cleaner region not found. Skipping it.");
				continue;
			}
			
			System.out.println("-Cleaner region found. Starting iteration through the layers.");

			//For each region iterate through all given layers that need to be cleaned.
			List<TiledMapLayer> layers = tiledMap.getMapLayers();
			for (TiledMapLayer layer : layers) {
				
				boolean clean = ignoreCleanerLayersNamesAndCleanAll || cleanerLayersNames.contains(layer.getName());
				clean &= !(layer.getName().equals("Background"));
				
				System.out.println("--Layer: " + layer.getName() + " " +(clean ? "will be cleaned." : "will not be cleaned"));
				
				if (clean) {
					
					//For each layer iterate through all tiles and check if they intersect with the region. If yes, clean the tile.
					Matrix<TiledTile> tiles = layer.getDataAsMatrix();
					
					System.out.print("---Cleaning tiles: ");
					for (int i = 0; i < tiles.w; i++) {
						for (int j = 0; j < tiles.h; j++) {
							PlacedRectangle r = PlacedRectangle.fromAnchorAndSize(i * tiledMap.getTileWidth(), j * tiledMap.getTileHeight(), tiledMap.getTileWidth(), tiledMap.getTileHeight());
							if (CollisionUtils.intersects(r, cleanerRegion)) {
								System.out.print(i + "/" + j + ";");
								TiledTile tile = tiles.getElement(i, j);
								tile.setGid(0);
							}
						}
					}
					System.out.println();
				}
				
			}
			
		}
		
		System.out.println("Cleaner processor finished. DON'T FORGET TO DELETE THE CLEANER REGION!!!");

	}

	public String getCleanerRegionsObjectGroupName() {
		return cleanerRegionsObjectGroupName;
	}

	public void setCleanerRegionsObjectGroupName(String cleanerRegionsObjectGroupName) {
		this.cleanerRegionsObjectGroupName = cleanerRegionsObjectGroupName;
	}

	public List<String> getCleanerRegionNames() {
		return cleanerRegionNames;
	}

	public List<String> getCleanerLayersNames() {
		return cleanerLayersNames;
	}

	public boolean isIgnoreCleanerLayersNamesAndCleanAll() {
		return ignoreCleanerLayersNamesAndCleanAll;
	}

	public void setIgnoreCleanerLayersNamesAndCleanAll(boolean ignoreCleanerLayersNamesAndCleanAll) {
		this.ignoreCleanerLayersNamesAndCleanAll = ignoreCleanerLayersNamesAndCleanAll;
	}
	
}












