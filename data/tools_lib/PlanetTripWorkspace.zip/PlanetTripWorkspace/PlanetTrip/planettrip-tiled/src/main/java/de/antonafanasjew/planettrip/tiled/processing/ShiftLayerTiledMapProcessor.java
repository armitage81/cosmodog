package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.util.Matrix;

public class ShiftLayerTiledMapProcessor extends AbstractTiledMapProcessor {

	private String fromLayer;
	private String toLayer;
	private boolean override;

	public ShiftLayerTiledMapProcessor(String fromLayer, String toLayer, boolean override) throws IOException {
		this.fromLayer = fromLayer;
		this.toLayer = toLayer;
		this.override = override;
	}

	@Override
	public void process(TiledMap tiledMap) {
		
		System.out.println("Shifting layer " + fromLayer + " to " +  toLayer);
		
		
		TiledMapLayer src = null;
		TiledMapLayer dest = null;
		
		for (TiledMapLayer layer : tiledMap.getMapLayers()) {
			if (layer.getName().equals(fromLayer)) {
				src = layer;
			}
			
			if (layer.getName().equals(toLayer)) {
				dest = layer;
			}
		}
		
		
		if (src == null || dest == null) {
			System.out.println("At least one of the layers does not exist in the map. Skipping shifting");
			return;
		}
		
		System.out.println("Both layers exist in the map. Start shifting");
		
		Matrix<TiledTile> srcTiles = src.getDataAsMatrix();
		Matrix<TiledTile> destTiles = dest.getDataAsMatrix();

		for (int k = 0; k < srcTiles.w; k++) {
			for (int l = 0; l < srcTiles.h; l++) {
				TiledTile tile = srcTiles.getElement(k, l);
				TiledTile tile2 = destTiles.getElement(k, l);
				if (tile.getGid() != 0) {
					if (tile2.getGid() == 0 || override) {
						destTiles.getElement(k, l).setGidFromTileNumber(tile.getGidAsTileNumber());
					}
				}
			}
		}
		
		System.out.println("Shifting complete.");

	}

}
