package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;

public class ResourceBasedObjectDistributionRuleProvider implements ObjectDistributionRuleProvider {

	public static final String PATH_TO_RULES_OBJECTS = "de/antonafanasjew/planettrip/tiled/objects.rules";
	public static final String PATH_TO_RULES_COLLECTIBLES = "de/antonafanasjew/planettrip/tiled/collectibles.rules";
	
	private String pathToRules;

	public ResourceBasedObjectDistributionRuleProvider(String pathToRules) {
		this.pathToRules = pathToRules;
	}
	
	@Override
	public ObjectDistributionRules provideObjectDistributionRules() throws IOException {
		
		ObjectDistributionRules retVal = new ObjectDistributionRules();
		
		InputStream resourceStream = EdgeLayoutTiledMapProcessor.class.getClassLoader().getResourceAsStream(pathToRules);
		String resouceContent = CharStreams.toString(new InputStreamReader(resourceStream, Charsets.UTF_8));
		String[] lines = resouceContent.split(System.getProperty("line.separator"));
		
		for (String line : lines) {
			
			String[] lineParts = line.split(":");
			String layer = lineParts[0];
			String undergroundLayer = lineParts[1];
			String undergroundTileNumbers = lineParts[2];
			String rulesForLayerText = lineParts[3];

			String[] rulesForLayer = rulesForLayerText.split(";");
			
			
			for (String ruleForLayer : rulesForLayer) {
				ObjectDistributionRule rule = new ObjectDistributionRule();
				rule.layer = layer;
				rule.undergroundLayer = undergroundLayer;
				
				String[] tileNumbersData = undergroundTileNumbers.split(";");
				
				for (String tileNumberData : tileNumbersData) {
					rule.undergroundTileNumbers.add(Integer.parseInt(tileNumberData)); 
				}
				
				
				String[] ruleData = ruleForLayer.split("=");
				
				rule.tileNumber = Integer.parseInt(ruleData[0]);
				rule.weight = Float.parseFloat(ruleData[1]);
				retVal.add(rule);
			}
			
		}
		return retVal;
	}

}
