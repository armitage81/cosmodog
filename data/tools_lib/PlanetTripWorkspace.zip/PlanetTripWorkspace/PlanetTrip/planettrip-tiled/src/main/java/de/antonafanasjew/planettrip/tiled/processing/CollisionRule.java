package de.antonafanasjew.planettrip.tiled.processing;

import java.util.Set;

import com.google.common.collect.Sets;

public class CollisionRule {
	
	public static final String COLLISION_TYPE_NO_PASSAGE = "noPassage";
	
	//f.i. noPassage
	public String type;
	public String markerLayer;
	public int markerTileNumber;
	public String description;
	public Set<String> tilesetReferences = Sets.newHashSet();
	public Set<String> ignoreTilesetReferences = Sets.newHashSet();
}
