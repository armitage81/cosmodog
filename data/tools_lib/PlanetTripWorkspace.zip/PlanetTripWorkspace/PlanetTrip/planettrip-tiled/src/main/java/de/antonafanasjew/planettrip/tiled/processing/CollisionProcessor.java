package de.antonafanasjew.planettrip.tiled.processing;

import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import de.antonafanasjew.planettrip.tiled.processingresources.LayerDescriptors;
import de.antonafanasjew.planettrip.tiled.processingresources.TilesetDescriptor;
import de.antonafanasjew.planettrip.tiled.processingresources.TilesetDescriptors;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.tiled.util.ParserUtils;
import de.antonafanasjew.planettrip.util.Matrix;

public class CollisionProcessor extends AbstractTiledMapProcessor {

	private static final int DEFAULT_COLLISION_TILE = 29;
	
	private TilesetDescriptors tilesets;
	private LayerDescriptors layerDescriptors;
	private CollisionRules rules;
	
	public CollisionProcessor(ResourceProvider<TilesetDescriptors> tilesetProvider, LayerDescriptorProvider layerDescriptorProvider, ResourceProvider<CollisionRules> collisionRulesProvider) {
		tilesets = tilesetProvider.provideResource("de/antonafanasjew/planettrip/tiled/tilesets.resource");
		layerDescriptors = layerDescriptorProvider.provideResource("de/antonafanasjew/planettrip/tiled/layers.resource");
		rules = collisionRulesProvider.provideResource("de/antonafanasjew/planettrip/tiled/collisions.rules");
	}
	
	@Override
	public void process(TiledMap tiledMap) {
		System.out.println("Starting collision calculation");
		
		Map<String, TiledMapLayer> layerByNameCache = Maps.newHashMap();
		Map<Integer, TiledMapLayer> layerByNumberCache = Maps.newHashMap();
		
		List<Matrix<TiledTile>> allLayersTiles = Lists.newArrayList();
		
		int layerNumber = 0;
		for (TiledMapLayer l : tiledMap.getMapLayers()) {
			layerByNameCache.put(l.getName(), l);
			layerByNumberCache.put(layerNumber, l);
			allLayersTiles.add(l.getDataAsMatrix());
			layerNumber++;
		}
		
		layerNumber = 0;
		
		//Filter irrelevant layer descriptors	
		LayerDescriptors relevantLayerDescriptors = layerDescriptors.filter(LayerDescriptors.PREDICATE_NOT_TOPS_AND_NOT_METAS);
		
		//Some rules use the same collision layer. The layer needs to be 
		//cleaned for the first rule but not for the subsequent rules (Otherwise it would delete collisions from the previous rules)
		//That's why the processed layers are stored.
		//In case a layer is in this set already, it won't be cleaned by the rule.
		Set<TiledMapLayer> processedCollisionLayers = Sets.newHashSet();
		
		for (CollisionRule rule : rules) {
			System.out.println("Adding collision type: " + rule.type + " on layer " + rule.markerLayer);
			TiledMapLayer collisionLayer = layerByNameCache.get(rule.markerLayer);
			
			boolean doClean = !processedCollisionLayers.contains(collisionLayer);
			processedCollisionLayers.add(collisionLayer);
			
			Set<Integer> collidingTileNumbers = collidingTileNumbers(rule);
			Set<Integer> ignoredTileNumbers = ignoredTileNumbers(rule);
			
			Matrix<TiledTile> collisionLayerTiles = collisionLayer.getDataAsMatrix();
			//go through each tile
			for (int k = 0; k < collisionLayerTiles.w; k++) {
				for (int l = 0; l < collisionLayerTiles.h; l++) {
					
					TiledTile collisionLayerTile = collisionLayerTiles.getElement(k, l);
					if (doClean) {
						collisionLayerTile.setGidFromTileNumber(DEFAULT_COLLISION_TILE);
					}
					
					//This can only happen if another collision rule has been applied already
					//on this tile stack. Ignore it in this case.
					if (collisionLayerTile.getGidAsTileNumber() != DEFAULT_COLLISION_TILE) {
						continue;
					}
					
					//Select the top tile which will be used as reference for the collision
					TiledTile referenceTile = null;
					
					for (int m = 0; m < layerByNumberCache.size(); m++) {
						
						//Ignore top and meta layers
						if (!relevantLayerDescriptors.keySet().contains(layerByNumberCache.get(m).getName())) {
							continue;
						}
						
						Matrix<TiledTile> oneLayerTiles = allLayersTiles.get(m);
						TiledTile layerTile = oneLayerTiles.getElement(k, l);
						int gid = layerTile.getGid();
						int tileNumber = layerTile.getGidAsTileNumber();
						if (gid != 0 && !ignoredTileNumbers.contains(tileNumber)) {
							referenceTile = layerTile;
						}
					}
					
					if (referenceTile != null) {
						int referenceTileNumber = referenceTile.getGidAsTileNumber();
						if (collidingTileNumbers.contains(referenceTileNumber)) {
							collisionLayerTile.setGidFromTileNumber(rule.markerTileNumber);
						}
					}
					
				}
			}
			
		}
		
		System.out.println("Collision calculation complete");
	}

	private Set<Integer> collidingTileNumbers(CollisionRule rule) {
		return tileNumbers(rule, true);
	}
	
	private Set<Integer> ignoredTileNumbers(CollisionRule rule) {
		return tileNumbers(rule, false);
	}
	
	private Set<Integer> tileNumbers(CollisionRule rule, boolean collidingNotIgnored) {
		
		Set<Integer> retVal = Sets.newHashSet();
		
		Set<String> collidingTilesetGroups = collidingNotIgnored ? rule.tilesetReferences : rule.ignoreTilesetReferences; 
		
		for (String group : collidingTilesetGroups) {
			Set<TilesetDescriptor> tilesetResources = tilesets.getTilesetResourcesForGroup(group);
			for (TilesetDescriptor res : tilesetResources) {
				Set<Integer> collidingTileNumbers = Sets.newHashSet();
				try {
					collidingTileNumbers = ParserUtils.parseIntegerSetFromTextAndRangeType(res.tileNumbers, res.type);
					//System.out.println("Resolved tile numbers for collision " + res.group + " " + res.hint + ":");
					//System.out.println(collidingTileNumbers);
				} catch (ParseException e) {
					System.err.println(e.getMessage());
				}
				retVal.addAll(collidingTileNumbers);
			}
		}
		
		return retVal;
	}

}
