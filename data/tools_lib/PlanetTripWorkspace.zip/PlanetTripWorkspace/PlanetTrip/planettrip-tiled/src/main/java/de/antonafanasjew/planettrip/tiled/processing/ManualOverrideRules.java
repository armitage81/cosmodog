package de.antonafanasjew.planettrip.tiled.processing;

import java.util.ArrayList;

import com.google.common.base.Joiner;

public class ManualOverrideRules extends ArrayList<ManualOverrideRule> {

	private static final long serialVersionUID = -8809501109445191557L;
	
	@Override
	public String toString() {
		return Joiner.on("|").join(this);
	}
	
	
	
}
