package de.antonafanasjew.planettrip.tiled.processing;

import java.io.IOException;
import java.io.InputStream;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

public abstract class AbstractResourceProvider<T> implements ResourceProvider<T> {

	@Override
	public T provideResource(String resourcePath) {
		
		InputStream resourceStream = AbstractResourceProvider.class.getClassLoader().getResourceAsStream(resourcePath);
		SAXBuilder jdomBuilder = new SAXBuilder();
		Document jdomDocument;
		try {
			jdomDocument = jdomBuilder.build(resourceStream);
			Element root = jdomDocument.getRootElement();
			return resourceFromRootElement(root);
		} catch (JDOMException | IOException e) {
			e.printStackTrace();
			return null;
		}
			
	}

	protected abstract T resourceFromRootElement(Element root);

}
