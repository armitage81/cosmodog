package de.antonafanasjew.planettrip.tiled.processing;

import java.util.ArrayList;

public class LayoutRules extends ArrayList<LayoutRule> {

	private static final long serialVersionUID = 2975968722396694451L;
	
}
