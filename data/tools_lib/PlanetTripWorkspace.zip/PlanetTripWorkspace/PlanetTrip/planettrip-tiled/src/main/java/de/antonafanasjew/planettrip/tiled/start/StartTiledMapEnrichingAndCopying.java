package de.antonafanasjew.planettrip.tiled.start;

import java.io.IOException;

import de.antonafanasjew.planettrip.tiled.io.TiledMapIoException;

public class StartTiledMapEnrichingAndCopying {

	public static void main(String[] args) throws IOException, TiledMapIoException {
		StartTiledMapEnriching.main(args);
		StartTiledMapCopying.main(args);
	}
	
}
