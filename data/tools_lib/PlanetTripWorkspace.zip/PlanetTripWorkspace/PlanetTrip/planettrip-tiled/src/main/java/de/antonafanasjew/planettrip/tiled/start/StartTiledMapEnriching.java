package de.antonafanasjew.planettrip.tiled.start;

import java.io.File;
import java.io.IOException;
import java.util.GregorianCalendar;

import com.google.common.io.Files;

import de.antonafanasjew.planettrip.tiled.Constants;
import de.antonafanasjew.planettrip.tiled.io.TiledMapIoException;
import de.antonafanasjew.planettrip.tiled.io.XmlTiledMapReader;
import de.antonafanasjew.planettrip.tiled.io.XmlTiledMapWriter;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;

/**
 * The writer contains the enriching logic which will add the height and width attributes to the object groups of the map.
 */
public class StartTiledMapEnriching {
	

	public static void main(String[] args) throws TiledMapIoException, IOException {
		
		String backupFileName = Constants.DEFAULT_BACKUP_MAP_FILE_NAME + new GregorianCalendar().getTimeInMillis();
		
		System.out.println("Creating a backup file: " + backupFileName);
		
		Files.copy(new File(Constants.MAP_FILE_NAME), new File(backupFileName));

		System.out.println("Reading the map file: " + Constants.MAP_FILE_NAME);
		
		XmlTiledMapReader reader = new XmlTiledMapReader(Constants.MAP_FILE_NAME);
		TiledMap map = reader.readTiledMap();
	
		System.out.println("Writing back the enriched map file");
		
		XmlTiledMapWriter writer = new XmlTiledMapWriter(Constants.MAP_FILE_NAME);
		writer.writeTiledMap(map);
		
		System.out.println("Finished.");
		
	}
	
}
