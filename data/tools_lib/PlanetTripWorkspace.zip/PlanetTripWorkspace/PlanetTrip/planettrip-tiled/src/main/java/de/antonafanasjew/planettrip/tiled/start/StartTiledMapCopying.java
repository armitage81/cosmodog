package de.antonafanasjew.planettrip.tiled.start;

import java.io.File;
import java.io.IOException;

import com.google.common.io.Files;

import de.antonafanasjew.planettrip.tiled.Constants;

public class StartTiledMapCopying {

	public static void main(String[] args) throws IOException {
		
		System.out.println("Copying map to: " + Constants.DESTINATION_MAP_FILE_NAME);
		
		Files.copy(new File(Constants.MAP_FILE_NAME), new File(Constants.DESTINATION_MAP_FILE_NAME));
		
		System.out.println("Copying tileset to: " + Constants.DESTINATION_TILESET_FILE_NAME);
		
		Files.copy(new File(Constants.TILESET_FILE_NAME), new File(Constants.DESTINATION_TILESET_FILE_NAME));
		
		System.out.println("Finished the copy process.");
	}
	
}
