package de.antonafanasjew.planettrip.tiled.io;

import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;

public interface TiledMapReader {

	TiledMap readTiledMap() throws TiledMapIoException;
	
}
