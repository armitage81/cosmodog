package de.antonafanasjew.planettrip.tiled.processing;

import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import de.antonafanasjew.planettrip.tiled.processingresources.LayerDescriptors;
import de.antonafanasjew.planettrip.tiled.processingresources.TilesetDescriptor;
import de.antonafanasjew.planettrip.tiled.processingresources.TilesetDescriptors;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMap;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledMapLayer;
import de.antonafanasjew.planettrip.tiled.tiledmap.TiledTile;
import de.antonafanasjew.planettrip.tiled.util.ParserUtils;
import de.antonafanasjew.planettrip.util.Matrix;

public class WaterplaceProcessor extends AbstractTiledMapProcessor {

	private static final int DEFAULT_WATERPLACE_TILE = -1;
	
	private TilesetDescriptors tilesets;
	private LayerDescriptors layerDescriptors;
	private WaterplaceRules rules;
	
	public WaterplaceProcessor(ResourceProvider<TilesetDescriptors> tilesetProvider, LayerDescriptorProvider layerDescriptorProvider, ResourceProvider<WaterplaceRules> waterplaceRulesProvider) {
		tilesets = tilesetProvider.provideResource("de/antonafanasjew/planettrip/tiled/tilesets.resource");
		layerDescriptors = layerDescriptorProvider.provideResource("de/antonafanasjew/planettrip/tiled/layers.resource");
		rules = waterplaceRulesProvider.provideResource("de/antonafanasjew/planettrip/tiled/waterplace.rules");
	}
	
	@Override
	public void process(TiledMap tiledMap) {
		System.out.println("Starting waterplace calculation");
		
		Map<String, TiledMapLayer> layerByNameCache = Maps.newHashMap();
		Map<Integer, TiledMapLayer> layerByNumberCache = Maps.newHashMap();
		
		List<Matrix<TiledTile>> allLayersTiles = Lists.newArrayList();
		
		int layerNumber = 0;
		for (TiledMapLayer l : tiledMap.getMapLayers()) {
			layerByNameCache.put(l.getName(), l);
			layerByNumberCache.put(layerNumber, l);
			allLayersTiles.add(l.getDataAsMatrix());
			layerNumber++;
		}
		
		layerNumber = 0;
		
		//Filter irrelevant layer descriptors	
		LayerDescriptors relevantLayerDescriptors = layerDescriptors.filter(LayerDescriptors.PREDICATE_NOT_TOPS_AND_NOT_METAS);
		
		Set<TiledMapLayer> processedWaterplaceLayers = Sets.newHashSet();
		
		for (WaterplaceRule rule : rules) {
			System.out.println("Adding waterplace type: " + rule.type + " on layer " + rule.markerLayer);
			
			
			//This is the layer on which the waterplace meta tiles will be added
			TiledMapLayer waterplaceLayer = layerByNameCache.get(rule.markerLayer);
			
			
			boolean doClean = !processedWaterplaceLayers.contains(waterplaceLayer);
			processedWaterplaceLayers.add(waterplaceLayer);
			
			//This are the tile numbers that are considered waterplaces
			Set<Integer> waterplaceTileNumbers = waterplaceTileNumbers(rule);
			
			//This are the tile numbers that will be ignored if they are on top of the tile stack while considering the layer for the 
			//waterplace calculation (f.i. If a rock tile is on top of a water tile it should be ignored so the water tile is relevant
			//for the waterplace calculation)
			Set<Integer> ignoredTileNumbers = ignoredTileNumbers(rule);
			
			//Meta tiles for waterplaces will be set on this matrix
			Matrix<TiledTile> waterplaceLayerTiles = waterplaceLayer.getDataAsMatrix();
			//go through each tile
			for (int k = 0; k < waterplaceLayerTiles.w; k++) {
				for (int l = 0; l < waterplaceLayerTiles.h; l++) {
					
					
					TiledTile waterplaceLayerTile = waterplaceLayerTiles.getElement(k, l);
					if (doClean) {
						waterplaceLayerTile.setGidFromTileNumber(DEFAULT_WATERPLACE_TILE);
					}
					
					//This can only happen if another waterplace rule has been applied already
					//on this tile stack. Ignore it in this case.
					if (waterplaceLayerTile.getGidAsTileNumber() != DEFAULT_WATERPLACE_TILE) {
						continue;
					}
					
					//Check all adjacent tiles AND the actual tile
					List<int[]> adjacentCoordinatesList = Lists.newArrayList();
					adjacentCoordinatesList.add(new int[]{k, l - 1});
					adjacentCoordinatesList.add(new int[]{k - 1, l});
					adjacentCoordinatesList.add(new int[]{k, l});
					adjacentCoordinatesList.add(new int[]{k + 1, l});
					adjacentCoordinatesList.add(new int[]{k, l + 1});
					
					for (int[] adgacentCoordinates : adjacentCoordinatesList) {
						
						int m = adgacentCoordinates[0];
						int n = adgacentCoordinates[1];
						
						//Select the top tile which will be used as reference for the waterplace calculation
						TiledTile referenceTile = null;
						
						for (int o = 0; o < layerByNumberCache.size(); o++) {
							
							//Ignore top and meta layers
							if (!relevantLayerDescriptors.keySet().contains(layerByNumberCache.get(o).getName())) {
								continue;
							}
							
							Matrix<TiledTile> oneLayerTiles = allLayersTiles.get(o);
							
							//As we check all adjacent tiles, we could hit beyond the map borders. So we ignore such cases
							if (m < 0 || m >= oneLayerTiles.w || n < 0 || n >= oneLayerTiles.h) {
								continue;
							}
							
							TiledTile layerTile = oneLayerTiles.getElement(m, n);
							int gid = layerTile.getGid();
							int tileNumber = layerTile.getGidAsTileNumber();
							if (gid != 0 && !ignoredTileNumbers.contains(tileNumber)) {
								referenceTile = layerTile;
							}
						}
						
						if (referenceTile != null) {
							int referenceTileNumber = referenceTile.getGidAsTileNumber();
							if (waterplaceTileNumbers.contains(referenceTileNumber)) {
								
								//the tile IS a water tile, not just close to water
								if (k == m && l == n) {
									waterplaceLayerTile.setGidFromTileNumber(rule.waterMarkerTileNumber);
									//A water tile can be (often) also attached to another water tile. So we have to break.
									break;
								} else {
									waterplaceLayerTile.setGidFromTileNumber(rule.closeToWaterMarkerTileNumber);
								}
							}
						}
					}
					
					
					
				}
			}
			
		}
		
		System.out.println("Waterplace calculation complete");
	}

	private Set<Integer> waterplaceTileNumbers(WaterplaceRule rule) {
		return tileNumbers(rule, true);
	}
	
	private Set<Integer> ignoredTileNumbers(WaterplaceRule rule) {
		return tileNumbers(rule, false);
	}
	
	private Set<Integer> tileNumbers(WaterplaceRule rule, boolean waterplaceNotIgnored) {
		
		Set<Integer> retVal = Sets.newHashSet();
		
		Set<String> waterplaceTilesetGroups = waterplaceNotIgnored ? rule.tilesetReferences : rule.ignoreTilesetReferences; 
		
		for (String group : waterplaceTilesetGroups) {
			Set<TilesetDescriptor> tilesetResources = tilesets.getTilesetResourcesForGroup(group);
			for (TilesetDescriptor res : tilesetResources) {
				Set<Integer> waterplaceTileNumbers = Sets.newHashSet();
				try {
					waterplaceTileNumbers = ParserUtils.parseIntegerSetFromTextAndRangeType(res.tileNumbers, res.type);
				} catch (ParseException e) {
					System.err.println(e.getMessage());
				}
				retVal.addAll(waterplaceTileNumbers);
			}
		}
		
		return retVal;
	}

}
