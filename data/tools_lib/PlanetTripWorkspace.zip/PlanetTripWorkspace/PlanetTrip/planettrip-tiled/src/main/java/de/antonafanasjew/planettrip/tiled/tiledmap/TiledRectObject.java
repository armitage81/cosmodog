package de.antonafanasjew.planettrip.tiled.tiledmap;

public class TiledRectObject extends TiledFigureObject {
	
}
