package de.antonafanasjew.planettrip.tiled;

public class Constants {

	public static final String MAP_FILE_NAME = "C:/Users/Anton/Documents/ProjectFolder/PlanetTrip/WorkArt/FinalMap.tmx";
	
	public static final String TILESET_FILE_NAME = "C:/Users/Anton/Documents/ProjectFolder/PlanetTrip/WorkArt/tiles.png";
	
	public static final String DEFAULT_BACKUP_MAP_FILE_NAME = Constants.MAP_FILE_NAME + ".bak.";

	public static final String DESTINATION_MAP_FILE_NAME = "C:/Workspaces/CosmodogGitWorkspace/cosmodog/data/FinalMap.tmx";
	public static final String DESTINATION_TILESET_FILE_NAME = "C:/Workspaces/CosmodogGitWorkspace/cosmodog/data/tiles.png";
	
}
