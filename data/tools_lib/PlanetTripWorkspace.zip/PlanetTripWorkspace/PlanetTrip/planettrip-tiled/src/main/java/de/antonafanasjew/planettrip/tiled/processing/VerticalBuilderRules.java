package de.antonafanasjew.planettrip.tiled.processing;

import java.util.ArrayList;

public class VerticalBuilderRules extends ArrayList<VerticalBuilderRule> {

	private static final long serialVersionUID = -1154099005213956954L;

}
