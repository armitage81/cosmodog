package de.antonafanasjew.planettrip.tiled.arithmetics;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import de.antonafanasjew.planettrip.util.Matrix;

public class NeighbourhoodProviderTest {

	NeighbourhoodProvider<MatrixElement> p;
	NeighbourhoodProvider<MatrixElement> p2;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	@Before
	public void setUp() throws Exception {
		
		Matrix<MatrixElement> matrix = new Matrix<MatrixElement>(new MatrixElement[][] {
				{ MatrixElement.MARKED, MatrixElement.MARKED, MatrixElement.MARKED, MatrixElement.MARKED, MatrixElement.MARKED },
				{ MatrixElement.MARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.MARKED },
				{ MatrixElement.MARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.MARKED },
				{ MatrixElement.MARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.MARKED },
				{ MatrixElement.MARKED, MatrixElement.MARKED, MatrixElement.MARKED, MatrixElement.MARKED, MatrixElement.MARKED } 
			}
		);
		
		p = new NeighbourhoodProvider<MatrixElement>(matrix);
		
		Matrix<MatrixElement> matrix2 = new Matrix<MatrixElement>(new MatrixElement[][] {
				{ MatrixElement.MARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.MARKED },
				{ MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED },
				{ MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED },
				{ MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED },
				{ MatrixElement.MARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.UNMARKED, MatrixElement.MARKED } 
			}
		);
		
		p2 = new NeighbourhoodProvider<MatrixElement>(matrix2);
		
	}

	@Test
	public void testEdges() throws UnknownNeighbourhoodException {
		assertEquals(MatrixNeighbourhood.northAndWest, p.provideNeighbourhood(1, 1));
		assertEquals(MatrixNeighbourhood.north, p.provideNeighbourhood(2, 1));
		assertEquals(MatrixNeighbourhood.northAndEast, p.provideNeighbourhood(3, 1));
		assertEquals(MatrixNeighbourhood.west, p.provideNeighbourhood(1, 2));
		assertEquals(MatrixNeighbourhood.none, p.provideNeighbourhood(2, 2));
		assertEquals(MatrixNeighbourhood.east, p.provideNeighbourhood(3, 2));
		assertEquals(MatrixNeighbourhood.southAndWest, p.provideNeighbourhood(1, 3));
		assertEquals(MatrixNeighbourhood.south, p.provideNeighbourhood(2, 3));
		assertEquals(MatrixNeighbourhood.southAndEast, p.provideNeighbourhood(3, 3));
	}
	
	@Test
	public void testCorners() throws UnknownNeighbourhoodException {
		assertEquals(MatrixNeighbourhood.northWest, p2.provideNeighbourhood(1, 1));
		assertEquals(MatrixNeighbourhood.northEast, p2.provideNeighbourhood(3, 1));
		assertEquals(MatrixNeighbourhood.southWest, p2.provideNeighbourhood(1, 3));
		assertEquals(MatrixNeighbourhood.southEast, p2.provideNeighbourhood(3, 3));
	}

}

class MatrixElement implements MarkableMatrixElement {

	public static MatrixElement MARKED = new MatrixElement(true);
	public static MatrixElement UNMARKED = new MatrixElement(false);

	private boolean marked;

	public MatrixElement(boolean marked) {
		this.marked = marked;
	}

	@Override
	public String toString() {
		return getMark().toString();
	}
	
	@Override
	public boolean isMarked() {
		return this.marked;
	}

	@Override
	public Object getMark() {
		return isMarked() ? "M" : "U";
	}

};